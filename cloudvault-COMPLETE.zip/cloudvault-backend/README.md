# ☁️ CloudVault AI — Backend API (المرحلة الثانية)

Node.js + Express + PostgreSQL + Prisma + JWT + Cloudflare R2

---

## 🚀 تشغيل محلي (بدون Docker)

### المتطلبات
- Node.js 18+
- PostgreSQL 14+
- Redis 7+ (اختياري)

### الخطوات

```bash
cd cloudvault-backend

# 1. تثبيت الحزم
npm install

# 2. تهيئة قاعدة البيانات (PostgreSQL يجب أن يكون شغالاً)
npx prisma migrate dev --name init
npx prisma generate

# 3. بيانات تجريبية
npm run prisma:seed

# 4. تشغيل
npm run dev
# API: http://localhost:5000
# Health: http://localhost:5000/health
```

---

## 🐳 تشغيل بـ Docker (الأسهل)

```bash
cd cloudvault-backend

# تشغيل PostgreSQL + Redis تلقائياً
docker-compose up -d postgres redis

# انتظر ثانية ثم شغّل migrations
npx prisma migrate dev --name init
npm run prisma:seed

# شغّل الـ API
npm run dev
```

---

## 📋 نقاط الـ API الكاملة

### Auth — `/api/v1/auth`
| Method | Path              | الوصف                    |
|--------|-------------------|--------------------------|
| POST   | `/register`       | إنشاء حساب جديد         |
| POST   | `/login`          | تسجيل الدخول            |
| POST   | `/refresh`        | تجديد access token       |
| POST   | `/logout`         | تسجيل الخروج            |
| GET    | `/me`             | بيانات المستخدم الحالي   |
| PATCH  | `/me`             | تحديث الملف الشخصي       |
| PATCH  | `/me/password`    | تغيير كلمة المرور        |

### Uploads — `/api/v1/uploads`
| Method | Path                  | الوصف                         |
|--------|-----------------------|-------------------------------|
| POST   | `/init`               | بدء جلسة رفع متعدد المقاطع   |
| POST   | `/chunk`              | رفع قطعة chunk                |
| POST   | `/complete`           | إنهاء الرفع المتعدد           |
| DELETE | `/:sessionId`         | إلغاء الرفع                   |
| GET    | `/:sessionId/status`  | حالة جلسة الرفع               |
| POST   | `/simple`             | رفع ملف صغير مباشر            |

### Files — `/api/v1/files`
| Method | Path              | الوصف                    |
|--------|-------------------|--------------------------|
| GET    | `/`               | قائمة الملفات (مع فلتر)  |
| GET    | `/stats`          | إحصائيات التخزين         |
| GET    | `/:id`            | ملف واحد                 |
| GET    | `/:id/download`   | تحميل (streaming)        |
| GET    | `/:id/stream`     | بث فيديو (range support) |
| GET    | `/:id/presign`    | رابط مباشر مؤقت         |
| PATCH  | `/:id`            | تحديث اسم / tags         |
| PATCH  | `/:id/star`       | تبديل المفضلة            |
| DELETE | `/:id`            | حذف نهائي                |
| DELETE | `/:id/soft`       | حذف إلى المهملات         |
| PATCH  | `/:id/restore`    | استعادة من المهملات      |
| POST   | `/bulk-delete`    | حذف متعدد                |

### Share — `/api/v1/share`
| Method | Path                    | الوصف                  |
|--------|-------------------------|------------------------|
| POST   | `/files/:id/share`      | إنشاء رابط مشاركة      |
| GET    | `/:token`               | فتح ملف مشارك (عام)    |
| GET    | `/:token/download`      | تحميل مشارك            |
| GET    | `/me/links`             | روابط مشاركتي          |
| DELETE | `/links/:shareId`       | إلغاء رابط             |

### Folders — `/api/v1/folders`
| Method | Path        | الوصف              |
|--------|-------------|--------------------|
| GET    | `/`         | قائمة المجلدات      |
| POST   | `/`         | مجلد جديد          |
| PATCH  | `/:id`      | تحديث المجلد        |
| DELETE | `/:id`      | حذف المجلد          |
| PATCH  | `/:id/star` | مفضلة المجلد        |

### Notifications — `/api/v1/notifications`
| Method | Path     | الوصف             |
|--------|----------|-------------------|
| GET    | `/`      | قائمة الإشعارات   |
| PATCH  | `/:id`   | تحديد كمقروء      |
| DELETE | `/:id`   | حذف إشعار          |

---

## 🔐 المصادقة

```bash
# تسجيل الدخول
curl -X POST http://localhost:5000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@cloudvault.ai","password":"Demo@123456"}'

# استخدام الـ token
curl http://localhost:5000/api/v1/files \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

---

## 📤 رفع ملف متعدد المقاطع (JavaScript)

```javascript
import { uploadApi } from '@/lib/api'

await uploadApi.uploadFile(file, {
  folderId: 'folder-id',
  onProgress: (pct, speed, eta) => console.log(`${pct}%`),
  onComplete: (fileData) => console.log('Done!', fileData),
})
```

---

## 🗄️ هيكل قاعدة البيانات

```
users          → المستخدمون (plan, storageUsed, etc.)
user_sessions  → جلسات تسجيل الدخول
folders        → المجلدات (nested, hierarchy)
files          → الملفات (R2 key, metadata, status)
upload_sessions→ جلسات الرفع المتعدد (chunk tracking)
share_links    → روابط المشاركة (password, expiry)
subtitles      → ترجمات AI
notifications  → الإشعارات
activity_logs  → سجل النشاط
```

---

## 🌐 نشر على Railway / Render (مجاناً)

### Railway
```bash
npm install -g @railway/cli
railway login
railway new
railway add postgresql
railway add redis
railway up
```

### Render
```
1. render.com → New Web Service
2. Connect GitHub repo (cloudvault-backend)
3. Build: npm install && npx prisma generate && npm run build
4. Start: node dist/server.js
5. Add PostgreSQL (free tier)
6. Add env vars
```

---

## 🔜 المرحلة الثالثة

- Cloudflare R2 تكامل حقيقي (upload + stream)
- معاينة ملفات في المتصفح
- توليد thumbnails تلقائي
- ضغط صور تلقائي
- روابط مشاركة مع CDN
