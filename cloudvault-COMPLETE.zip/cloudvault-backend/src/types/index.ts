import { Request } from 'express'

export interface AuthRequest extends Request {
  user?: { id: string; email: string; role: string; plan: string }
}

export interface ApiResponse<T = unknown> {
  success: boolean
  message?: string
  data?: T
  error?: string
  meta?: { page?: number; limit?: number; total?: number; totalPages?: number }
}

export interface JwtPayload {
  id: string; email: string; role: string; plan: string; iat?: number; exp?: number
}

export interface InitUploadBody {
  fileName: string; mimeType: string; totalSize: number
  chunkSize?: number; checksum?: string; folderId?: string
}

export interface ChunkUploadBody {
  sessionId: string; chunkIndex: number; totalChunks: number
}

export interface FileQueryParams {
  page?: string; limit?: string
  sortBy?: 'name' | 'size' | 'createdAt' | 'updatedAt'
  order?: 'asc' | 'desc'; search?: string; mimeType?: string
  folderId?: string; isStarred?: string; isShared?: string; tags?: string
}

export interface CreateShareBody {
  type?: 'VIEW' | 'DOWNLOAD' | 'EDIT'
  password?: string; expiresIn?: number
  maxDownloads?: number; allowedEmails?: string[]
}
