import dotenv from 'dotenv'
dotenv.config()

export const env = {
  NODE_ENV:          process.env.NODE_ENV ?? 'development',
  PORT:              parseInt(process.env.PORT ?? '5000'),
  API_PREFIX:        process.env.API_PREFIX ?? '/api/v1',
  FRONTEND_URL:      process.env.FRONTEND_URL ?? 'http://localhost:3000',

  JWT_SECRET:             process.env.JWT_SECRET ?? 'dev-secret',
  JWT_EXPIRES_IN:         process.env.JWT_EXPIRES_IN ?? '7d',
  JWT_REFRESH_SECRET:     process.env.JWT_REFRESH_SECRET ?? 'dev-refresh',
  JWT_REFRESH_EXPIRES_IN: process.env.JWT_REFRESH_EXPIRES_IN ?? '30d',

  CLOUDFLARE_ACCOUNT_ID:  process.env.CLOUDFLARE_ACCOUNT_ID ?? '',
  R2_ACCESS_KEY_ID:       process.env.R2_ACCESS_KEY_ID ?? '',
  R2_SECRET_ACCESS_KEY:   process.env.R2_SECRET_ACCESS_KEY ?? '',
  R2_BUCKET_NAME:         process.env.R2_BUCKET_NAME ?? 'cloudvault-files',
  R2_PUBLIC_URL:          process.env.R2_PUBLIC_URL ?? '',
  R2_ENDPOINT:            process.env.R2_ENDPOINT ?? '',

  MAX_FILE_SIZE:     parseInt(process.env.MAX_FILE_SIZE ?? '10737418240'),
  CHUNK_SIZE:        parseInt(process.env.CHUNK_SIZE ?? '5242880'),
  UPLOAD_TEMP_DIR:   process.env.UPLOAD_TEMP_DIR ?? '/tmp/cloudvault-uploads',

  OPENAI_API_KEY:    process.env.OPENAI_API_KEY ?? '',
  RESEND_API_KEY:    process.env.RESEND_API_KEY ?? '',
  EMAIL_FROM:        process.env.EMAIL_FROM ?? 'noreply@cloudvault.ai',

  FREE_STORAGE_LIMIT: BigInt(process.env.FREE_STORAGE_LIMIT ?? '2199023255552'),
  PRO_STORAGE_LIMIT:  BigInt(process.env.PRO_STORAGE_LIMIT ?? '10995116277760'),
}
