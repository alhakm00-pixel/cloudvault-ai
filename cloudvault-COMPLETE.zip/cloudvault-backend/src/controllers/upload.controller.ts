import { Response } from 'express'
import path from 'path'
import fs from 'fs'
import crypto from 'crypto'
import prisma from '../config/database'
import { AuthRequest, InitUploadBody, ChunkUploadBody } from '../types'
import { sendSuccess, sendError } from '../utils/response'
import { logger } from '../utils/logger'
import { env } from '../config/env'
import {
  createMultipartUpload, uploadPart, completeMultipartUpload,
  abortMultipartUpload, uploadObject, buildStorageKey, buildPublicUrl,
} from '../services/r2.service'
import { processFile, checkQuota } from '../services/storage.service'

// ─── Helper: check storage quota ─────────────────────────────────────────────
async function checkQuota(userId: string, fileSize: number): Promise<boolean> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { storageUsed: true, storageTotal: true },
  })
  if (!user) return false
  return (user.storageUsed + BigInt(fileSize)) <= user.storageTotal
}

// ─── 1. Initialise upload session ────────────────────────────────────────────
export async function initUpload(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { fileName, mimeType, totalSize, chunkSize, checksum, folderId } = req.body as InitUploadBody
    const userId = req.user!.id

    if (!(await checkQuota(userId, totalSize))) {
      sendError(res, 'المساحة التخزينية غير كافية — قم بترقية خطتك', 413)
      return
    }

    const storageKey    = buildStorageKey(userId, fileName)
    const resolvedChunk = chunkSize ?? env.CHUNK_SIZE
    const totalChunks   = Math.ceil(totalSize / resolvedChunk)

    // Create R2 multipart upload
    const uploadId = await createMultipartUpload(storageKey, mimeType)

    // Persist session
    const expiresAt = new Date()
    expiresAt.setHours(expiresAt.getHours() + 24)

    const session = await prisma.uploadSession.create({
      data: {
        userId, fileName, mimeType,
        totalSize: BigInt(totalSize),
        chunkSize: resolvedChunk,
        totalChunks,
        storageKey,
        uploadId,
        checksumMd5: checksum,
        status: 'IN_PROGRESS',
        expiresAt,
        ...(folderId ? {} : {}),
      },
    })

    logger.info(`Upload initiated: ${session.id} — ${fileName} (${totalChunks} chunks)`)
    sendSuccess(res, {
      sessionId: session.id,
      storageKey,
      chunkSize: resolvedChunk,
      totalChunks,
      uploadId,
    }, 'تم بدء جلسة الرفع', 201)
  } catch (err) {
    logger.error('initUpload error:', err)
    sendError(res, 'فشل بدء جلسة الرفع', 500)
  }
}

// ─── 2. Upload a single chunk ─────────────────────────────────────────────────
export async function uploadChunk(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { sessionId, chunkIndex } = req.body as unknown as ChunkUploadBody
    const userId = req.user!.id
    const buffer = req.file?.buffer

    if (!buffer) { sendError(res, 'بيانات القطعة مطلوبة', 400); return }

    const session = await prisma.uploadSession.findFirst({
      where: { id: sessionId, userId, status: 'IN_PROGRESS' },
    })
    if (!session) { sendError(res, 'جلسة الرفع غير موجودة أو منتهية', 404); return }
    if (!session.uploadId) { sendError(res, 'معرّف الرفع المتعدد مفقود', 400); return }

    const partNumber = parseInt(String(chunkIndex)) + 1 // R2 parts start at 1

    // Upload part to R2
    const part = await uploadPart(session.storageKey, session.uploadId, partNumber, buffer)

    // Mark chunk as uploaded
    const uploadedChunks = [...session.uploadedChunks, parseInt(String(chunkIndex))]
    const progress = Math.round((uploadedChunks.length / session.totalChunks) * 100)

    await prisma.uploadSession.update({
      where: { id: sessionId },
      data:  { uploadedChunks },
    })

    logger.debug(`Chunk ${partNumber}/${session.totalChunks} uploaded for session ${sessionId}`)
    sendSuccess(res, {
      chunkIndex: parseInt(String(chunkIndex)),
      progress,
      uploadedChunks: uploadedChunks.length,
      totalChunks: session.totalChunks,
      etag: part.ETag,
    }, `القطعة ${partNumber} تم رفعها`)
  } catch (err) {
    logger.error('uploadChunk error:', err)
    sendError(res, 'فشل رفع القطعة', 500)
  }
}

// ─── 3. Complete upload ───────────────────────────────────────────────────────
export async function completeUpload(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { sessionId, parts } = req.body as { sessionId: string; parts: { ETag: string; PartNumber: number }[] }
    const userId = req.user!.id

    const session = await prisma.uploadSession.findFirst({
      where: { id: sessionId, userId },
    })
    if (!session) { sendError(res, 'جلسة الرفع غير موجودة', 404); return }
    if (!session.uploadId) { sendError(res, 'معرّف الرفع مفقود', 400); return }

    // Complete R2 multipart
    const publicUrl = await completeMultipartUpload(session.storageKey, session.uploadId, parts)

    // Derive file metadata
    const ext  = path.extname(session.fileName).slice(1).toLowerCase()
    const name = path.basename(session.fileName, path.extname(session.fileName))

    // Create File record
    const file = await prisma.file.create({
      data: {
        userId,
        name,
        originalName: session.fileName,
        mimeType:     session.mimeType,
        size:         session.totalSize,
        extension:    ext,
        status:       'READY',
        storageKey:   session.storageKey,
        storageUrl:   publicUrl,
      },
    })

    // Update upload session
    await prisma.uploadSession.update({
      where: { id: sessionId },
      data:  { status: 'COMPLETED', fileId: file.id },
    })

    // Increment storage used
    await prisma.user.update({
      where: { id: userId },
      data:  { storageUsed: { increment: session.totalSize } },
    })

    // Notification
    await prisma.notification.create({
      data: {
        userId,
        title: 'اكتمل الرفع ✅',
        message: `تم رفع "${session.fileName}" بنجاح`,
        type: 'upload_complete',
        data: { fileId: file.id },
      },
    })

    logger.info(`Upload complete: ${file.id} — ${session.fileName}`)
    sendSuccess(res, { file, url: publicUrl }, 'تم رفع الملف بنجاح')
  } catch (err) {
    logger.error('completeUpload error:', err)
    sendError(res, 'فشل اكتمال الرفع', 500)
  }
}

// ─── 4. Abort upload ─────────────────────────────────────────────────────────
export async function abortUpload(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { sessionId } = req.params
    const userId = req.user!.id

    const session = await prisma.uploadSession.findFirst({
      where: { id: sessionId, userId },
    })
    if (!session) { sendError(res, 'الجلسة غير موجودة', 404); return }

    if (session.uploadId) {
      await abortMultipartUpload(session.storageKey, session.uploadId).catch(() => {})
    }

    await prisma.uploadSession.update({
      where: { id: sessionId },
      data:  { status: 'FAILED' },
    })

    sendSuccess(res, null, 'تم إلغاء الرفع')
  } catch (err) {
    logger.error('abortUpload error:', err)
    sendError(res, 'فشل إلغاء الرفع', 500)
  }
}

// ─── 5. Upload status ────────────────────────────────────────────────────────
export async function getUploadStatus(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { sessionId } = req.params
    const session = await prisma.uploadSession.findFirst({
      where: { id: sessionId, userId: req.user!.id },
    })
    if (!session) { sendError(res, 'الجلسة غير موجودة', 404); return }

    const progress = Math.round((session.uploadedChunks.length / session.totalChunks) * 100)
    sendSuccess(res, {
      sessionId: session.id,
      status: session.status,
      progress,
      uploadedChunks: session.uploadedChunks.length,
      totalChunks: session.totalChunks,
      missingChunks: Array.from({ length: session.totalChunks }, (_, i) => i)
        .filter((i) => !session.uploadedChunks.includes(i)),
    })
  } catch (err) {
    logger.error('getUploadStatus error:', err)
    sendError(res, 'فشل جلب حالة الرفع', 500)
  }
}

// ─── 6. Simple (small file) upload ───────────────────────────────────────────
export async function simpleUpload(req: AuthRequest, res: Response): Promise<void> {
  try {
    if (!req.file) { sendError(res, 'الملف مطلوب', 400); return }
    const userId = req.user!.id
    const { folderId } = req.body

    if (!(await checkQuota(userId, req.file.size))) {
      sendError(res, 'المساحة التخزينية غير كافية', 413)
      return
    }

    const storageKey = buildStorageKey(userId, req.file.originalname)
    const buffer     = req.file.buffer ?? fs.readFileSync(req.file.path!)
    const url        = await uploadObject(storageKey, buffer, req.file.mimetype)

    // Clean up temp file if disk storage was used
    if (req.file.path) fs.unlink(req.file.path, () => {})

    const ext  = path.extname(req.file.originalname).slice(1).toLowerCase()
    const name = path.basename(req.file.originalname, path.extname(req.file.originalname))

    const file = await prisma.file.create({
      data: {
        userId,
        name,
        originalName: req.file.originalname,
        mimeType:     req.file.mimetype,
        size:         BigInt(req.file.size),
        extension:    ext,
        status:       'READY',
        storageKey,
        storageUrl:   url,
        ...(folderId ? { folderId } : {}),
      },
    })

    await prisma.user.update({
      where: { id: userId },
      data:  { storageUsed: { increment: BigInt(req.file.size) } },
    })

    sendSuccess(res, { file, url }, 'تم رفع الملف بنجاح', 201)
  } catch (err) {
    logger.error('simpleUpload error:', err)
    sendError(res, 'فشل رفع الملف', 500)
  }
}
