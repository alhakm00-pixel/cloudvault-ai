import { Response } from 'express'
import { Readable } from 'stream'
import prisma from '../config/database'
import { AuthRequest, FileQueryParams } from '../types'
import { sendSuccess, sendError, sendPaginated } from '../utils/response'
import { logger } from '../utils/logger'
import {
  getObjectStream, deleteObject, presignedDownloadUrl, buildPublicUrl,
} from '../services/r2.service'

// ─── List files ───────────────────────────────────────────────────────────────
export async function listFiles(req: AuthRequest, res: Response): Promise<void> {
  try {
    const userId = req.user!.id
    const {
      page = '1', limit = '20', sortBy = 'createdAt', order = 'desc',
      search, mimeType, folderId, isStarred, isShared, tags,
    } = req.query as FileQueryParams

    const skip  = (parseInt(page) - 1) * parseInt(limit)
    const take  = Math.min(parseInt(limit), 100)

    const where: Record<string, unknown> = {
      userId,
      deletedAt: null,
      status: 'READY',
      ...(search && { name: { contains: search, mode: 'insensitive' } }),
      ...(mimeType && { mimeType: { startsWith: mimeType } }),
      ...(folderId !== undefined && { folderId: folderId || null }),
      ...(isStarred === 'true' && { isStarred: true }),
      ...(isShared  === 'true' && { isShared:  true }),
      ...(tags && { tags: { hasSome: tags.split(',') } }),
    }

    const [files, total] = await Promise.all([
      prisma.file.findMany({
        where,
        orderBy: { [sortBy]: order },
        skip, take,
        select: {
          id: true, name: true, originalName: true, mimeType: true, size: true,
          extension: true, status: true, storageUrl: true, thumbnailUrl: true,
          duration: true, width: true, height: true, isStarred: true,
          isShared: true, tags: true, downloadCount: true, viewCount: true,
          folderId: true, createdAt: true, updatedAt: true,
        },
      }),
      prisma.file.count({ where }),
    ])

    sendPaginated(res, files, total, parseInt(page), take)
  } catch (err) {
    logger.error('listFiles error:', err)
    sendError(res, 'فشل جلب الملفات', 500)
  }
}

// ─── Get single file ──────────────────────────────────────────────────────────
export async function getFile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: null },
      include: { subtitles: true, shareLinks: { where: { isActive: true } } },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    // Increment view count
    await prisma.file.update({ where: { id }, data: { viewCount: { increment: 1 } } })

    sendSuccess(res, file)
  } catch (err) {
    logger.error('getFile error:', err)
    sendError(res, 'فشل جلب الملف', 500)
  }
}

// ─── Download (streaming) ─────────────────────────────────────────────────────
export async function downloadFile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file   = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: null, status: 'READY' },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    const range = req.headers.range

    // Get object from R2 (with optional range for video streaming)
    const s3res = await getObjectStream(file.storageKey, range)

    res.setHeader('Content-Type', file.mimeType)
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(file.originalName)}"`)
    res.setHeader('Accept-Ranges', 'bytes')
    res.setHeader('Cache-Control', 'no-store')

    if (s3res.ContentLength) {
      res.setHeader('Content-Length', s3res.ContentLength.toString())
    }
    if (s3res.ContentRange) {
      res.setHeader('Content-Range', s3res.ContentRange)
      res.status(206)
    }

    if (s3res.Body instanceof Readable) {
      s3res.Body.pipe(res)
    } else {
      const bytes = await (s3res.Body as any).transformToByteArray()
      res.send(Buffer.from(bytes))
    }

    // Update download count (fire-and-forget)
    prisma.file.update({
      where: { id },
      data:  { downloadCount: { increment: 1 } },
    }).catch(() => {})

  } catch (err) {
    logger.error('downloadFile error:', err)
    if (!res.headersSent) sendError(res, 'فشل تحميل الملف', 500)
  }
}

// ─── Stream video ─────────────────────────────────────────────────────────────
export async function streamVideo(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file   = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: null, status: 'READY' },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    if (!file.mimeType.startsWith('video/') && !file.mimeType.startsWith('audio/')) {
      sendError(res, 'هذا الملف ليس وسائط', 400)
      return
    }

    const range = req.headers.range
    if (!range) {
      res.setHeader('Content-Type', file.mimeType)
      const s3res = await getObjectStream(file.storageKey)
      if (s3res.ContentLength) res.setHeader('Content-Length', s3res.ContentLength.toString())
      if (s3res.Body instanceof Readable) s3res.Body.pipe(res)
      return
    }

    const s3res = await getObjectStream(file.storageKey, range)
    res.status(206)
    res.setHeader('Content-Type', file.mimeType)
    res.setHeader('Accept-Ranges', 'bytes')
    if (s3res.ContentLength)  res.setHeader('Content-Length', s3res.ContentLength.toString())
    if (s3res.ContentRange)   res.setHeader('Content-Range', s3res.ContentRange)

    if (s3res.Body instanceof Readable) {
      s3res.Body.pipe(res)
    } else {
      const bytes = await (s3res.Body as any).transformToByteArray()
      res.send(Buffer.from(bytes))
    }
  } catch (err) {
    logger.error('streamVideo error:', err)
    if (!res.headersSent) sendError(res, 'فشل تشغيل الملف', 500)
  }
}

// ─── Presigned download URL ───────────────────────────────────────────────────
export async function getPresignedUrl(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file   = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: null },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    const url = await presignedDownloadUrl(file.storageKey, 3600)
    sendSuccess(res, { url, expiresIn: 3600 })
  } catch (err) {
    logger.error('getPresignedUrl error:', err)
    sendError(res, 'فشل توليد الرابط المؤقت', 500)
  }
}

// ─── Update file ──────────────────────────────────────────────────────────────
export async function updateFile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id }   = req.params
    const { name, tags, folderId } = req.body

    const file = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: null },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    const updated = await prisma.file.update({
      where: { id },
      data: {
        ...(name     && { name }),
        ...(tags     && { tags }),
        ...(folderId !== undefined && { folderId: folderId || null }),
      },
    })
    sendSuccess(res, updated, 'تم تحديث الملف')
  } catch (err) {
    logger.error('updateFile error:', err)
    sendError(res, 'فشل تحديث الملف', 500)
  }
}

// ─── Toggle star ──────────────────────────────────────────────────────────────
export async function toggleStar(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file   = await prisma.file.findFirst({
      where: { id, userId: req.user!.id },
      select: { id: true, isStarred: true },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    const updated = await prisma.file.update({
      where: { id },
      data:  { isStarred: !file.isStarred },
      select: { id: true, isStarred: true },
    })
    sendSuccess(res, updated, updated.isStarred ? 'تمت الإضافة للمفضلة' : 'تمت الإزالة من المفضلة')
  } catch (err) {
    logger.error('toggleStar error:', err)
    sendError(res, 'فشل تحديث المفضلة', 500)
  }
}

// ─── Soft delete ──────────────────────────────────────────────────────────────
export async function softDeleteFile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file   = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: null },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    await prisma.file.update({ where: { id }, data: { deletedAt: new Date() } })
    sendSuccess(res, null, 'تم نقل الملف إلى المحذوفات')
  } catch (err) {
    logger.error('softDelete error:', err)
    sendError(res, 'فشل حذف الملف', 500)
  }
}

// ─── Permanent delete ─────────────────────────────────────────────────────────
export async function deleteFile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file   = await prisma.file.findFirst({
      where: { id, userId: req.user!.id },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    // Delete from R2
    await deleteObject(file.storageKey)
    if (file.thumbnailKey) await deleteObject(file.thumbnailKey).catch(() => {})

    // Free up storage
    await prisma.user.update({
      where: { id: req.user!.id },
      data:  { storageUsed: { decrement: file.size } },
    })

    await prisma.file.delete({ where: { id } })
    sendSuccess(res, null, 'تم حذف الملف نهائياً')
  } catch (err) {
    logger.error('deleteFile error:', err)
    sendError(res, 'فشل حذف الملف', 500)
  }
}

// ─── Restore from trash ───────────────────────────────────────────────────────
export async function restoreFile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file   = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: { not: null } },
    })
    if (!file) { sendError(res, 'الملف غير موجود في المحذوفات', 404); return }

    await prisma.file.update({ where: { id }, data: { deletedAt: null } })
    sendSuccess(res, null, 'تم استعادة الملف')
  } catch (err) {
    logger.error('restoreFile error:', err)
    sendError(res, 'فشل استعادة الملف', 500)
  }
}

// ─── Bulk delete ─────────────────────────────────────────────────────────────
export async function bulkDelete(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { ids, permanent = false } = req.body as { ids: string[]; permanent?: boolean }
    const userId = req.user!.id

    if (!Array.isArray(ids) || ids.length === 0) {
      sendError(res, 'يجب تحديد ملف واحد على الأقل', 400)
      return
    }

    const files = await prisma.file.findMany({
      where: { id: { in: ids }, userId },
      select: { id: true, storageKey: true, thumbnailKey: true, size: true },
    })

    if (permanent) {
      // Delete from R2
      await Promise.allSettled(files.map((f) => deleteObject(f.storageKey)))
      await Promise.allSettled(files.filter(f => f.thumbnailKey).map((f) => deleteObject(f.thumbnailKey!)))

      const totalSize = files.reduce((s, f) => s + f.size, BigInt(0))
      await prisma.user.update({
        where: { id: userId },
        data:  { storageUsed: { decrement: totalSize } },
      })
      await prisma.file.deleteMany({ where: { id: { in: ids }, userId } })
    } else {
      await prisma.file.updateMany({
        where: { id: { in: ids }, userId },
        data:  { deletedAt: new Date() },
      })
    }

    sendSuccess(res, { deleted: files.length }, `تم حذف ${files.length} ملف`)
  } catch (err) {
    logger.error('bulkDelete error:', err)
    sendError(res, 'فشل الحذف المتعدد', 500)
  }
}

// ─── Storage stats ────────────────────────────────────────────────────────────
export async function getStorageStats(req: AuthRequest, res: Response): Promise<void> {
  try {
    const userId = req.user!.id
    const user   = await prisma.user.findUnique({
      where: { id: userId },
      select: { storageUsed: true, storageTotal: true },
    })
    if (!user) { sendError(res, 'المستخدم غير موجود', 404); return }

    const [totalFiles, byType] = await Promise.all([
      prisma.file.count({ where: { userId, deletedAt: null, status: 'READY' } }),
      prisma.file.groupBy({
        by: ['mimeType'],
        where: { userId, deletedAt: null, status: 'READY' },
        _count: { id: true },
        _sum:   { size: true },
        orderBy: { _sum: { size: 'desc' } },
        take: 10,
      }),
    ])

    sendSuccess(res, {
      totalFiles,
      storageUsed: user.storageUsed.toString(),
      storageTotal: user.storageTotal.toString(),
      storagePercent: Number((user.storageUsed * BigInt(100)) / user.storageTotal),
      byType: byType.map((t) => ({
        mimeType: t.mimeType,
        count: t._count.id,
        size: t._sum.size?.toString() ?? '0',
      })),
    })
  } catch (err) {
    logger.error('getStorageStats error:', err)
    sendError(res, 'فشل جلب إحصائيات التخزين', 500)
  }
}
