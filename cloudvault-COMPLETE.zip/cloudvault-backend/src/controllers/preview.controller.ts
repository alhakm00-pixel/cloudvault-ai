import { Response } from 'express'
import { AuthRequest } from '../types'
import { sendSuccess, sendError } from '../utils/response'
import { getPreviewData } from '../services/storage.service'
import { streamFile } from '../services/stream.service'
import { presignedDownloadUrl } from '../services/r2.service'
import prisma from '../config/database'
import { logger } from '../utils/logger'

// ─── Get preview metadata + signed URL ───────────────────────────────────────
export async function getPreview(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id }  = req.params
    const userId  = req.user!.id
    const preview = await getPreviewData(id, userId)

    // Increment view count
    prisma.file.update({ where: { id }, data: { viewCount: { increment: 1 } } }).catch(() => {})

    sendSuccess(res, preview)
  } catch (err: any) {
    logger.error('getPreview error:', err)
    sendError(res, err.message ?? 'فشل جلب معاينة الملف', 404)
  }
}

// ─── Inline stream (image, PDF, text) ────────────────────────────────────────
export async function inlineFile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: null, status: 'READY' },
      select: { storageKey: true, mimeType: true, originalName: true },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    await streamFile(
      res,
      file.storageKey,
      file.mimeType,
      file.originalName,
      req.headers.range,
      true, // inline
    )
  } catch (err) {
    logger.error('inlineFile error:', err)
    if (!res.headersSent) sendError(res, 'فشل معاينة الملف', 500)
  }
}

// ─── Thumbnail stream ─────────────────────────────────────────────────────────
export async function getThumbnail(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file = await prisma.file.findFirst({
      where: { id, userId: req.user!.id },
      select: { thumbnailKey: true, thumbnailUrl: true },
    })
    if (!file?.thumbnailKey) { sendError(res, 'لا توجد صورة مصغّرة', 404); return }

    res.setHeader('Cache-Control', 'public, max-age=86400') // 1 day
    await streamFile(res, file.thumbnailKey, 'image/webp', 'thumbnail.webp', undefined, true)
  } catch (err) {
    logger.error('getThumbnail error:', err)
    if (!res.headersSent) sendError(res, 'فشل جلب الصورة المصغّرة', 500)
  }
}

// ─── Public shared file preview ───────────────────────────────────────────────
export async function publicPreview(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { token } = req.params

    const share = await prisma.shareLink.findUnique({
      where: { token },
      include: {
        file: {
          select: {
            id: true, name: true, originalName: true, mimeType: true,
            size: true, storageKey: true, storageUrl: true,
            thumbnailUrl: true, duration: true, width: true, height: true,
            createdAt: true, isEncrypted: true,
          },
        },
      },
    })

    if (!share || !share.isActive) { sendError(res, 'الرابط غير صالح أو منتهي', 404); return }
    if (share.expiresAt && share.expiresAt < new Date()) {
      await prisma.shareLink.update({ where: { token }, data: { isActive: false } })
      sendError(res, 'انتهت صلاحية هذا الرابط', 410)
      return
    }

    // Generate a 1-hour signed URL for the actual file
    const signedUrl = await presignedDownloadUrl(share.file.storageKey, 3600)

    let previewType = 'download'
    const m = share.file.mimeType
    if (m.startsWith('image/'))       previewType = 'image'
    else if (m.startsWith('video/'))  previewType = 'video'
    else if (m.startsWith('audio/'))  previewType = 'audio'
    else if (m === 'application/pdf') previewType = 'pdf'
    else if (m.startsWith('text/'))   previewType = 'text'

    sendSuccess(res, {
      file: share.file,
      previewType,
      signedUrl,
      shareType: share.type,
      canDownload: share.type !== 'VIEW',
    })
  } catch (err) {
    logger.error('publicPreview error:', err)
    sendError(res, 'فشل جلب معاينة الملف المشارك', 500)
  }
}
