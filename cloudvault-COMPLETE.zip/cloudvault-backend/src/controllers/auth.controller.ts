import { Request, Response } from 'express'
import { body } from 'express-validator'
import prisma from '../config/database'
import { hashPassword, comparePassword, generateToken } from '../utils/crypto'
import { signAccessToken, signRefreshToken, verifyRefreshToken } from '../services/jwt.service'
import { sendSuccess, sendError } from '../utils/response'
import { AuthRequest } from '../types'
import { env } from '../config/env'
import { logger } from '../utils/logger'

// ─── Validators ──────────────────────────────────────────────────────────────
export const registerValidators = [
  body('name').trim().notEmpty().withMessage('الاسم مطلوب').isLength({ min: 2, max: 80 }),
  body('email').isEmail().normalizeEmail().withMessage('البريد الإلكتروني غير صحيح'),
  body('password').isLength({ min: 8 }).withMessage('كلمة المرور يجب أن تكون 8 أحرف على الأقل'),
]

export const loginValidators = [
  body('email').isEmail().normalizeEmail().withMessage('البريد الإلكتروني غير صحيح'),
  body('password').notEmpty().withMessage('كلمة المرور مطلوبة'),
]

// ─── Register ────────────────────────────────────────────────────────────────
export async function register(req: Request, res: Response): Promise<void> {
  try {
    const { name, email, password } = req.body

    const existing = await prisma.user.findUnique({ where: { email } })
    if (existing) {
      sendError(res, 'البريد الإلكتروني مسجّل بالفعل', 409)
      return
    }

    const hashed = await hashPassword(password)
    const user   = await prisma.user.create({
      data: {
        name, email,
        password: hashed,
        storageTotal: env.FREE_STORAGE_LIMIT,
      },
      select: { id: true, name: true, email: true, plan: true, role: true, createdAt: true },
    })

    const payload  = { id: user.id, email: user.email, role: user.role, plan: user.plan }
    const access   = signAccessToken(payload)
    const refresh  = signRefreshToken(payload)

    // Persist refresh token
    await prisma.user.update({ where: { id: user.id }, data: { refreshToken: refresh } })

    // Create welcome notification
    await prisma.notification.create({
      data: {
        userId: user.id,
        title: 'مرحباً بك في CloudVault AI! 🎉',
        message: 'حسابك جاهز مع 2TB مساحة مجانية. ابدأ برفع ملفاتك الآن.',
        type: 'welcome',
      },
    })

    logger.info(`New user registered: ${email}`)
    sendSuccess(res, { user, accessToken: access, refreshToken: refresh }, 'تم إنشاء الحساب بنجاح', 201)
  } catch (err) {
    logger.error('Register error:', err)
    sendError(res, 'فشل إنشاء الحساب', 500)
  }
}

// ─── Login ───────────────────────────────────────────────────────────────────
export async function login(req: Request, res: Response): Promise<void> {
  try {
    const { email, password } = req.body

    const user = await prisma.user.findUnique({
      where: { email },
      select: {
        id: true, name: true, email: true, password: true,
        role: true, plan: true, isActive: true,
        storageUsed: true, storageTotal: true, avatar: true,
      },
    })

    if (!user || !(await comparePassword(password, user.password))) {
      sendError(res, 'البريد الإلكتروني أو كلمة المرور غير صحيحة', 401)
      return
    }

    if (!user.isActive) {
      sendError(res, 'الحساب موقوف — تواصل مع الدعم', 403)
      return
    }

    const payload = { id: user.id, email: user.email, role: user.role, plan: user.plan }
    const access  = signAccessToken(payload)
    const refresh = signRefreshToken(payload)

    await prisma.user.update({
      where: { id: user.id },
      data: {
        refreshToken: refresh,
        lastLoginAt: new Date(),
        lastLoginIp: req.ip,
      },
    })

    // Create session record
    const expiresAt = new Date()
    expiresAt.setDate(expiresAt.getDate() + 30)
    await prisma.userSession.create({
      data: {
        userId: user.id,
        token: refresh,
        ipAddress: req.ip ?? 'unknown',
        userAgent: req.headers['user-agent'] ?? 'unknown',
        expiresAt,
      },
    })

    const { password: _, ...safeUser } = user
    sendSuccess(res, { user: safeUser, accessToken: access, refreshToken: refresh }, 'تم تسجيل الدخول بنجاح')
  } catch (err) {
    logger.error('Login error:', err)
    sendError(res, 'فشل تسجيل الدخول', 500)
  }
}

// ─── Refresh token ───────────────────────────────────────────────────────────
export async function refreshToken(req: Request, res: Response): Promise<void> {
  try {
    const { refreshToken: token } = req.body
    if (!token) { sendError(res, 'Refresh token مطلوب', 400); return }

    const payload = verifyRefreshToken(token)
    const user    = await prisma.user.findUnique({
      where: { id: payload.id },
      select: { id: true, email: true, role: true, plan: true, refreshToken: true, isActive: true },
    })

    if (!user || user.refreshToken !== token || !user.isActive) {
      sendError(res, 'Refresh token غير صالح', 401)
      return
    }

    const newPayload = { id: user.id, email: user.email, role: user.role, plan: user.plan }
    const access     = signAccessToken(newPayload)
    const refresh    = signRefreshToken(newPayload)

    await prisma.user.update({ where: { id: user.id }, data: { refreshToken: refresh } })

    sendSuccess(res, { accessToken: access, refreshToken: refresh }, 'تم تجديد الجلسة')
  } catch {
    sendError(res, 'Refresh token منتهي الصلاحية', 401)
  }
}

// ─── Logout ──────────────────────────────────────────────────────────────────
export async function logout(req: AuthRequest, res: Response): Promise<void> {
  try {
    if (req.user?.id) {
      await prisma.user.update({
        where: { id: req.user.id },
        data: { refreshToken: null },
      })
      await prisma.userSession.updateMany({
        where: { userId: req.user.id, isActive: true },
        data:  { isActive: false },
      })
    }
    sendSuccess(res, null, 'تم تسجيل الخروج بنجاح')
  } catch (err) {
    logger.error('Logout error:', err)
    sendError(res, 'فشل تسجيل الخروج', 500)
  }
}

// ─── Get current user ────────────────────────────────────────────────────────
export async function getMe(req: AuthRequest, res: Response): Promise<void> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
      select: {
        id: true, name: true, email: true, avatar: true,
        role: true, plan: true, storageUsed: true, storageTotal: true,
        emailVerified: true, twoFAEnabled: true,
        lastLoginAt: true, createdAt: true,
      },
    })
    if (!user) { sendError(res, 'المستخدم غير موجود', 404); return }
    sendSuccess(res, user)
  } catch (err) {
    logger.error('getMe error:', err)
    sendError(res, 'فشل جلب بيانات المستخدم', 500)
  }
}

// ─── Update profile ──────────────────────────────────────────────────────────
export async function updateProfile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { name, avatar } = req.body
    const user = await prisma.user.update({
      where: { id: req.user!.id },
      data: { ...(name && { name }), ...(avatar && { avatar }) },
      select: { id: true, name: true, email: true, avatar: true },
    })
    sendSuccess(res, user, 'تم تحديث الملف الشخصي')
  } catch (err) {
    logger.error('updateProfile error:', err)
    sendError(res, 'فشل تحديث الملف الشخصي', 500)
  }
}

// ─── Change password ─────────────────────────────────────────────────────────
export async function changePassword(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { currentPassword, newPassword } = req.body
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
      select: { password: true },
    })
    if (!user || !(await comparePassword(currentPassword, user.password))) {
      sendError(res, 'كلمة المرور الحالية غير صحيحة', 400)
      return
    }
    const hashed = await hashPassword(newPassword)
    await prisma.user.update({ where: { id: req.user!.id }, data: { password: hashed } })
    sendSuccess(res, null, 'تم تغيير كلمة المرور بنجاح')
  } catch (err) {
    logger.error('changePassword error:', err)
    sendError(res, 'فشل تغيير كلمة المرور', 500)
  }
}
