import { Response } from 'express'
import bcrypt from 'bcryptjs'
import prisma from '../config/database'
import { AuthRequest, CreateShareBody } from '../types'
import { sendSuccess, sendError } from '../utils/response'
import { logger } from '../utils/logger'
import { presignedDownloadUrl } from '../services/r2.service'

// ─── Create share link ────────────────────────────────────────────────────────
export async function createShareLink(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id: fileId } = req.params
    const { type = 'VIEW', password, expiresIn, maxDownloads, allowedEmails } = req.body as CreateShareBody
    const userId = req.user!.id

    const file = await prisma.file.findFirst({
      where: { id: fileId, userId, deletedAt: null, status: 'READY' },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    const hashedPassword = password ? await bcrypt.hash(password, 10) : null

    let expiresAt: Date | null = null
    if (expiresIn) {
      expiresAt = new Date()
      expiresAt.setHours(expiresAt.getHours() + expiresIn)
    }

    const share = await prisma.shareLink.create({
      data: {
        fileId, userId,
        type,
        password: hashedPassword,
        expiresAt,
        maxDownloads: maxDownloads ?? null,
        allowedEmails: allowedEmails ?? [],
      },
    })

    await prisma.file.update({ where: { id: fileId }, data: { isShared: true } })

    const shareUrl = `${process.env.FRONTEND_URL}/share/${share.token}`
    sendSuccess(res, { share: { ...share, password: undefined }, shareUrl }, 'تم إنشاء رابط المشاركة', 201)
  } catch (err) {
    logger.error('createShareLink error:', err)
    sendError(res, 'فشل إنشاء رابط المشاركة', 500)
  }
}

// ─── Get shared file (public) ─────────────────────────────────────────────────
export async function getSharedFile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { token } = req.params
    const { password } = req.body

    const share = await prisma.shareLink.findUnique({
      where: { token },
      include: {
        file: {
          select: {
            id: true, name: true, originalName: true, mimeType: true,
            size: true, storageUrl: true, thumbnailUrl: true,
            duration: true, width: true, height: true, createdAt: true,
          },
        },
      },
    })

    if (!share || !share.isActive) { sendError(res, 'الرابط غير صالح أو منتهي', 404); return }
    if (share.expiresAt && share.expiresAt < new Date()) {
      await prisma.shareLink.update({ where: { token }, data: { isActive: false } })
      sendError(res, 'انتهت صلاحية هذا الرابط', 410)
      return
    }
    if (share.maxDownloads && share.downloadCount >= share.maxDownloads) {
      sendError(res, 'تجاوز الرابط الحد الأقصى للتحميلات', 410)
      return
    }
    if (share.password) {
      if (!password) { sendError(res, 'هذا الرابط محمي بكلمة مرور', 401); return }
      const valid = await bcrypt.compare(password, share.password)
      if (!valid) { sendError(res, 'كلمة المرور غير صحيحة', 401); return }
    }

    sendSuccess(res, { file: share.file, shareType: share.type })
  } catch (err) {
    logger.error('getSharedFile error:', err)
    sendError(res, 'فشل جلب الملف المشارك', 500)
  }
}

// ─── List user's share links ──────────────────────────────────────────────────
export async function listShareLinks(req: AuthRequest, res: Response): Promise<void> {
  try {
    const links = await prisma.shareLink.findMany({
      where: { userId: req.user!.id },
      include: {
        file: { select: { id: true, name: true, mimeType: true, size: true } },
      },
      orderBy: { createdAt: 'desc' },
    })
    const sanitized = links.map(({ password: _, ...l }) => l)
    sendSuccess(res, sanitized)
  } catch (err) {
    logger.error('listShareLinks error:', err)
    sendError(res, 'فشل جلب روابط المشاركة', 500)
  }
}

// ─── Revoke share link ────────────────────────────────────────────────────────
export async function revokeShareLink(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { shareId } = req.params
    const link = await prisma.shareLink.findFirst({
      where: { id: shareId, userId: req.user!.id },
    })
    if (!link) { sendError(res, 'الرابط غير موجود', 404); return }

    await prisma.shareLink.update({ where: { id: shareId }, data: { isActive: false } })

    // If no more active links for this file, mark as unshared
    const remaining = await prisma.shareLink.count({
      where: { fileId: link.fileId, isActive: true },
    })
    if (remaining === 0) {
      await prisma.file.update({ where: { id: link.fileId }, data: { isShared: false } })
    }

    sendSuccess(res, null, 'تم إلغاء رابط المشاركة')
  } catch (err) {
    logger.error('revokeShareLink error:', err)
    sendError(res, 'فشل إلغاء الرابط', 500)
  }
}

// ─── Download via share link ──────────────────────────────────────────────────
export async function downloadShared(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { token } = req.params

    const share = await prisma.shareLink.findUnique({
      where: { token },
      include: { file: true },
    })

    if (!share?.isActive || (share.expiresAt && share.expiresAt < new Date())) {
      sendError(res, 'الرابط غير صالح', 404)
      return
    }
    if (share.type === 'VIEW') {
      sendError(res, 'هذا الرابط للعرض فقط، لا يسمح بالتحميل', 403)
      return
    }

    const url = await presignedDownloadUrl(share.file.storageKey, 300)
    await prisma.shareLink.update({
      where: { token },
      data:  { downloadCount: { increment: 1 } },
    })

    sendSuccess(res, { url, fileName: share.file.originalName })
  } catch (err) {
    logger.error('downloadShared error:', err)
    sendError(res, 'فشل تحميل الملف المشارك', 500)
  }
}
