import { Response } from 'express'
import prisma from '../config/database'
import { AuthRequest } from '../types'
import { sendSuccess, sendError } from '../utils/response'
import { logger } from '../utils/logger'

export async function listNotifications(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { page = '1', limit = '20', unreadOnly } = req.query
    const skip = (parseInt(page as string) - 1) * parseInt(limit as string)
    const where = {
      userId: req.user!.id,
      ...(unreadOnly === 'true' && { isRead: false }),
    }
    const [notifications, total, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where, orderBy: { createdAt: 'desc' },
        skip, take: parseInt(limit as string),
      }),
      prisma.notification.count({ where }),
      prisma.notification.count({ where: { userId: req.user!.id, isRead: false } }),
    ])
    sendSuccess(res, { notifications, unreadCount }, 'نجح الطلب', 200, {
      page: parseInt(page as string),
      limit: parseInt(limit as string),
      total,
      totalPages: Math.ceil(total / parseInt(limit as string)),
    })
  } catch (err) {
    logger.error('listNotifications error:', err)
    sendError(res, 'فشل جلب الإشعارات', 500)
  }
}

export async function markAsRead(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    if (id === 'all') {
      await prisma.notification.updateMany({
        where: { userId: req.user!.id, isRead: false },
        data:  { isRead: true },
      })
      sendSuccess(res, null, 'تم تحديد جميع الإشعارات كمقروءة')
    } else {
      const n = await prisma.notification.findFirst({ where: { id, userId: req.user!.id } })
      if (!n) { sendError(res, 'الإشعار غير موجود', 404); return }
      await prisma.notification.update({ where: { id }, data: { isRead: true } })
      sendSuccess(res, null, 'تم تحديد الإشعار كمقروء')
    }
  } catch (err) {
    logger.error('markAsRead error:', err)
    sendError(res, 'فشل تحديث الإشعار', 500)
  }
}

export async function deleteNotification(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const n = await prisma.notification.findFirst({ where: { id, userId: req.user!.id } })
    if (!n) { sendError(res, 'الإشعار غير موجود', 404); return }
    await prisma.notification.delete({ where: { id } })
    sendSuccess(res, null, 'تم حذف الإشعار')
  } catch (err) {
    logger.error('deleteNotification error:', err)
    sendError(res, 'فشل حذف الإشعار', 500)
  }
}
