import { Response } from 'express'
import prisma from '../config/database'
import { AuthRequest } from '../types'
import { sendSuccess, sendError } from '../utils/response'
import { logger } from '../utils/logger'

export async function createFolder(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { name, parentId, color, icon } = req.body
    const userId = req.user!.id

    if (!name?.trim()) { sendError(res, 'اسم المجلد مطلوب', 400); return }

    if (parentId) {
      const parent = await prisma.folder.findFirst({ where: { id: parentId, userId } })
      if (!parent) { sendError(res, 'المجلد الأب غير موجود', 404); return }
    }

    const folder = await prisma.folder.create({
      data: { name: name.trim(), userId, parentId: parentId ?? null, color, icon },
    })
    sendSuccess(res, folder, 'تم إنشاء المجلد', 201)
  } catch (err) {
    logger.error('createFolder error:', err)
    sendError(res, 'فشل إنشاء المجلد', 500)
  }
}

export async function listFolders(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { parentId } = req.query
    const folders = await prisma.folder.findMany({
      where: {
        userId: req.user!.id,
        parentId: (parentId as string) ?? null,
      },
      include: {
        _count: { select: { files: true, children: true } },
      },
      orderBy: { name: 'asc' },
    })
    sendSuccess(res, folders)
  } catch (err) {
    logger.error('listFolders error:', err)
    sendError(res, 'فشل جلب المجلدات', 500)
  }
}

export async function updateFolder(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const { name, color, icon, parentId } = req.body

    const folder = await prisma.folder.findFirst({ where: { id, userId: req.user!.id } })
    if (!folder) { sendError(res, 'المجلد غير موجود', 404); return }

    const updated = await prisma.folder.update({
      where: { id },
      data: {
        ...(name     && { name }),
        ...(color    && { color }),
        ...(icon     && { icon }),
        ...(parentId !== undefined && { parentId: parentId || null }),
      },
    })
    sendSuccess(res, updated, 'تم تحديث المجلد')
  } catch (err) {
    logger.error('updateFolder error:', err)
    sendError(res, 'فشل تحديث المجلد', 500)
  }
}

export async function deleteFolder(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const folder = await prisma.folder.findFirst({ where: { id, userId: req.user!.id } })
    if (!folder) { sendError(res, 'المجلد غير موجود', 404); return }

    // Soft-delete all files inside
    await prisma.file.updateMany({
      where: { folderId: id, userId: req.user!.id },
      data:  { deletedAt: new Date() },
    })

    await prisma.folder.delete({ where: { id } })
    sendSuccess(res, null, 'تم حذف المجلد')
  } catch (err) {
    logger.error('deleteFolder error:', err)
    sendError(res, 'فشل حذف المجلد', 500)
  }
}

export async function toggleStarFolder(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const folder = await prisma.folder.findFirst({
      where: { id, userId: req.user!.id },
      select: { id: true, isStarred: true },
    })
    if (!folder) { sendError(res, 'المجلد غير موجود', 404); return }

    const updated = await prisma.folder.update({
      where: { id },
      data:  { isStarred: !folder.isStarred },
    })
    sendSuccess(res, updated)
  } catch (err) {
    logger.error('toggleStarFolder error:', err)
    sendError(res, 'فشل تحديث المفضلة', 500)
  }
}
