import { Response } from 'express'
import fs from 'fs'
import path from 'path'
import prisma from '../config/database'
import { AuthRequest } from '../types'
import { sendSuccess, sendError } from '../utils/response'
import { logger } from '../utils/logger'
import { getObjectBuffer } from '../services/r2.service'
import {
  transcribeWithWhisper, translateToArabic, generateSrt,
  generateVtt, uploadSubtitle, generateSummary,
  searchInTranscript, extractAudio,
} from '../services/whisper.service'
import { semanticSearch, autoTagFile, chatWithFile } from '../services/ai.service'
import { env } from '../config/env'

// ─── Generate subtitles ───────────────────────────────────────────────────────
export async function generateSubtitles(req: AuthRequest, res: Response): Promise<void> {
  const { id } = req.params
  const { language = 'auto', translate = true } = req.body
  const userId = req.user!.id

  try {
    const file = await prisma.file.findFirst({
      where: { id, userId, deletedAt: null, status: 'READY' },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    const isMedia = file.mimeType.startsWith('video/') || file.mimeType.startsWith('audio/')
    if (!isMedia) { sendError(res, 'هذا الملف ليس وسائط صوتية أو مرئية', 400); return }

    // Mark file as processing
    await prisma.file.update({ where: { id }, data: { status: 'PROCESSING' } })

    // Download file from R2 to temp
    const tmpDir  = '/tmp/cv-ai'
    fs.mkdirSync(tmpDir, { recursive: true })
    const tmpFile = path.join(tmpDir, `${id}_${file.extension ?? 'mp4'}`)
    const tmpAudio = path.join(tmpDir, `${id}.wav`)

    logger.info(`Downloading file for transcription: ${id}`)
    const buffer = await getObjectBuffer(file.storageKey)
    fs.writeFileSync(tmpFile, buffer)

    // Extract audio if video
    if (file.mimeType.startsWith('video/')) {
      await extractAudio(tmpFile, tmpAudio)
    } else {
      fs.copyFileSync(tmpFile, tmpAudio)
    }

    // Transcribe
    logger.info(`Starting Whisper transcription: ${id}`)
    const transcription = await transcribeWithWhisper(tmpAudio, language === 'auto' ? undefined : language)

    let segments = transcription.segments

    // Translate to Arabic if requested and source isn't Arabic
    if (translate && transcription.detectedLanguage !== 'ar') {
      logger.info(`Translating ${segments.length} segments to Arabic`)
      segments = await translateToArabic(segments)
    }

    // Generate SRT and VTT (original)
    const srtOrig = generateSrt(segments, false)
    const vttOrig = generateVtt(segments, false)

    // Generate Arabic SRT and VTT
    const srtAr = segments.some(s => s.textAr) ? generateSrt(segments, true)  : null
    const vttAr = segments.some(s => s.textAr) ? generateVtt(segments, true)  : null

    // Upload subtitle files to R2
    const origLang = transcription.detectedLanguage
    const srtUrl   = await uploadSubtitle(srtOrig, userId, id, origLang, 'srt')
    const vttUrl   = await uploadSubtitle(vttOrig, userId, id, origLang, 'vtt')

    let srtArUrl: string | null = null
    let vttArUrl: string | null = null
    if (srtAr && vttAr) {
      srtArUrl = await uploadSubtitle(srtAr, userId, id, 'ar', 'srt')
      vttArUrl = await uploadSubtitle(vttAr, userId, id, 'ar', 'vtt')
    }

    // Save subtitles to DB
    await prisma.subtitle.createMany({
      data: [
        {
          fileId:     id,
          language:   origLang,
          label:      origLang === 'ar' ? 'عربي' : origLang === 'en' ? 'English' : origLang,
          storageKey: `users/${userId}/subtitles/${id}/${origLang}.vtt`,
          url:        vttUrl,
          isAI:       true,
        },
        ...(vttArUrl ? [{
          fileId:     id,
          language:   'ar',
          label:      'عربي (AI)',
          storageKey: `users/${userId}/subtitles/${id}/ar.vtt`,
          url:        vttArUrl,
          isAI:       true,
        }] : []),
      ],
      skipDuplicates: true,
    })

    // Save transcript + update file
    const fullTranscript = segments.map(s => s.text).join(' ')
    await prisma.file.update({
      where: { id },
      data:  {
        status:   'READY',
        duration: Math.round(transcription.duration),
        metadata: {
          transcript:        fullTranscript,
          transcriptAr:      segments.some(s => s.textAr) ? segments.map(s => s.textAr).join(' ') : null,
          detectedLanguage:  transcription.detectedLanguage,
          segmentCount:      segments.length,
          transcribedAt:     new Date().toISOString(),
        } as any,
      },
    })

    // Cleanup temp files
    ;[tmpFile, tmpAudio].forEach(f => { try { fs.unlinkSync(f) } catch {} })

    // Auto-tag
    const tags = await autoTagFile(file.name, file.mimeType, fullTranscript)
    if (tags.length) await prisma.file.update({ where: { id }, data: { tags } })

    sendSuccess(res, {
      segments,
      detectedLanguage: transcription.detectedLanguage,
      duration:         transcription.duration,
      segmentCount:     segments.length,
      subtitles: {
        original: { srt: srtUrl,   vtt: vttUrl   },
        arabic:   { srt: srtArUrl, vtt: vttArUrl },
      },
      hasTranslation: !!vttArUrl,
    }, 'تم توليد الترجمة بنجاح')
  } catch (err: any) {
    logger.error('generateSubtitles error:', err)
    await prisma.file.update({ where: { id }, data: { status: 'READY' } }).catch(() => {})
    sendError(res, `فشل توليد الترجمة: ${err.message}`, 500)
  }
}

// ─── Get subtitles for a file ─────────────────────────────────────────────────
export async function getSubtitles(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file   = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: null },
      include: { subtitles: { orderBy: { createdAt: 'asc' } } },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }
    sendSuccess(res, { subtitles: file.subtitles, metadata: file.metadata })
  } catch (err) {
    logger.error('getSubtitles error:', err)
    sendError(res, 'فشل جلب الترجمات', 500)
  }
}

// ─── Get subtitle file content (VTT/SRT) ─────────────────────────────────────
export async function getSubtitleFile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { subtitleId } = req.params
    const sub = await prisma.subtitle.findUnique({ where: { id: subtitleId } })
    if (!sub) { sendError(res, 'الترجمة غير موجودة', 404); return }

    const buf = await getObjectBuffer(sub.storageKey)
    const ext = sub.storageKey.endsWith('.srt') ? 'srt' : 'vtt'
    res.setHeader('Content-Type', ext === 'vtt' ? 'text/vtt; charset=utf-8' : 'text/plain; charset=utf-8')
    res.setHeader('Content-Disposition', `inline; filename="${sub.language}.${ext}"`)
    res.setHeader('Cache-Control', 'public, max-age=3600')
    res.end(buf)
  } catch (err) {
    logger.error('getSubtitleFile error:', err)
    sendError(res, 'فشل جلب ملف الترجمة', 500)
  }
}

// ─── Generate AI summary ──────────────────────────────────────────────────────
export async function generateAISummary(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id }       = req.params
    const { language } = req.body
    const file         = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: null },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    const meta       = (file.metadata as any) ?? {}
    const transcript = meta.transcript ?? meta.transcriptAr ?? ''

    if (!transcript) {
      sendError(res, 'لا يوجد نص مستخرج — قم بتوليد الترجمة أولاً', 400)
      return
    }

    const summary = await generateSummary(transcript, file.name, language ?? 'ar')

    // Cache summary in metadata
    await prisma.file.update({
      where: { id },
      data:  {
        metadata: {
          ...meta,
          summary:   summary.summary,
          keyPoints: summary.keyPoints,
          topics:    summary.topics,
          summarizedAt: new Date().toISOString(),
        } as any,
      },
    })

    sendSuccess(res, summary, 'تم توليد الملخص بنجاح')
  } catch (err) {
    logger.error('generateAISummary error:', err)
    sendError(res, 'فشل توليد الملخص', 500)
  }
}

// ─── Search inside file content ───────────────────────────────────────────────
export async function searchInFile(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id }    = req.params
    const { query } = req.query as { query: string }

    if (!query?.trim()) { sendError(res, 'استعلام البحث مطلوب', 400); return }

    const file = await prisma.file.findFirst({
      where:   { id, userId: req.user!.id, deletedAt: null },
      include: { subtitles: true },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    const meta     = (file.metadata as any) ?? {}
    const transcript = meta.transcript ?? ''
    if (!transcript) {
      sendError(res, 'لا يوجد نص مستخرج لهذا الملف', 400)
      return
    }

    // Reconstruct segments from metadata if stored
    const storedSegments = meta.segments ?? []
    if (!storedSegments.length) {
      // Simple text search fallback
      const q    = query.toLowerCase()
      const hits = transcript.toLowerCase().split('.').filter((s: string) => s.includes(q))
      sendSuccess(res, { results: hits.map((h: string, i: number) => ({ index: i, text: h, highlight: h })) })
      return
    }

    const results = await searchInTranscript(storedSegments, query)
    sendSuccess(res, { results, query, totalFound: results.length })
  } catch (err) {
    logger.error('searchInFile error:', err)
    sendError(res, 'فشل البحث في الملف', 500)
  }
}

// ─── Smart search across all files ───────────────────────────────────────────
export async function smartSearch(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { q, limit = '20' } = req.query as { q: string; limit?: string }
    if (!q?.trim()) { sendError(res, 'استعلام البحث مطلوب', 400); return }

    const userId = req.user!.id
    const files  = await prisma.file.findMany({
      where: { userId, deletedAt: null, status: 'READY' },
      select: { id: true, name: true, tags: true, mimeType: true, metadata: true,
                storageUrl: true, thumbnailUrl: true, size: true, createdAt: true },
      take: 200,
    })

    // Basic keyword match first
    const qLower = q.toLowerCase()
    const keywordMatches = files.filter(f =>
      f.name.toLowerCase().includes(qLower) ||
      f.tags.some(t => t.toLowerCase().includes(qLower)) ||
      ((f.metadata as any)?.transcript ?? '').toLowerCase().includes(qLower),
    )

    // AI semantic search on remaining
    const nonMatches = files.filter(f => !keywordMatches.find(m => m.id === f.id))
    const aiResults  = nonMatches.length > 0
      ? await semanticSearch(q, nonMatches.map(f => ({ id: f.id, name: f.name, tags: f.tags, mimeType: f.mimeType })))
      : []

    // Merge and deduplicate
    const merged = [
      ...keywordMatches.map(f => ({ ...f, score: 1.0,  reason: 'تطابق نصي مباشر' })),
      ...aiResults.map(r => {
        const file = files.find(f => f.id === r.id)
        return file ? { ...file, score: r.score, reason: r.reason } : null
      }).filter(Boolean),
    ]
    .slice(0, parseInt(limit))

    sendSuccess(res, { results: merged, query: q, total: merged.length })
  } catch (err) {
    logger.error('smartSearch error:', err)
    sendError(res, 'فشل البحث الذكي', 500)
  }
}

// ─── Chat with file content ───────────────────────────────────────────────────
export async function chatWithFileContent(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id }      = req.params
    const { message, history = [] } = req.body

    if (!message?.trim()) { sendError(res, 'الرسالة مطلوبة', 400); return }

    const file = await prisma.file.findFirst({
      where: { id, userId: req.user!.id, deletedAt: null },
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    const meta       = (file.metadata as any) ?? {}
    const transcript = meta.transcript ?? meta.transcriptAr ?? ''
    if (!transcript) {
      sendError(res, 'لا يوجد محتوى نصي لهذا الملف — قم بتوليد الترجمة أولاً', 400)
      return
    }

    const reply = await chatWithFile(message, transcript, file.name, history)
    sendSuccess(res, { reply, fileId: id })
  } catch (err) {
    logger.error('chatWithFileContent error:', err)
    sendError(res, 'فشل المحادثة مع الملف', 500)
  }
}

// ─── Get AI status for a file ─────────────────────────────────────────────────
export async function getAIStatus(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params
    const file   = await prisma.file.findFirst({
      where: { id, userId: req.user!.id },
      include: { subtitles: true },
      select: {
        id: true, metadata: true, status: true,
        mimeType: true, subtitles: true,
      } as any,
    })
    if (!file) { sendError(res, 'الملف غير موجود', 404); return }

    const meta = (file.metadata as any) ?? {}
    sendSuccess(res, {
      hasTranscript:  !!meta.transcript,
      hasSummary:     !!meta.summary,
      hasSubtitles:   (file.subtitles?.length ?? 0) > 0,
      subtitleCount:  file.subtitles?.length ?? 0,
      detectedLang:   meta.detectedLanguage,
      transcribedAt:  meta.transcribedAt,
      summarizedAt:   meta.summarizedAt,
      segmentCount:   meta.segmentCount ?? 0,
      topics:         meta.topics ?? [],
    })
  } catch (err) {
    logger.error('getAIStatus error:', err)
    sendError(res, 'فشل جلب حالة AI', 500)
  }
}
