import multer from 'multer'
import path from 'path'
import fs from 'fs'
import { env } from '../config/env'
import { Request } from 'express'

// Ensure temp dir exists
fs.mkdirSync(env.UPLOAD_TEMP_DIR, { recursive: true })

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, env.UPLOAD_TEMP_DIR),
  filename: (_req, file, cb) => {
    const unique = `${Date.now()}-${Math.random().toString(36).slice(2)}`
    const ext    = path.extname(file.originalname)
    cb(null, `${unique}${ext}`)
  },
})

const memoryStorage = multer.memoryStorage()

function fileFilter(_req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) {
  // Block executables
  const blocked = ['.exe', '.bat', '.cmd', '.sh', '.ps1', '.vbs', '.js', '.php']
  const ext = path.extname(file.originalname).toLowerCase()
  if (blocked.includes(ext)) {
    cb(new Error('نوع الملف غير مسموح به'))
    return
  }
  cb(null, true)
}

// Disk-based (for large files / chunks)
export const diskUpload = multer({
  storage,
  fileFilter,
  limits: { fileSize: env.MAX_FILE_SIZE },
})

// Memory-based (for small files: thumbnails, avatars)
export const memUpload = multer({
  storage: memoryStorage,
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
})

// Single chunk upload (memory)
export const chunkUpload = multer({
  storage: memoryStorage,
  limits: { fileSize: env.CHUNK_SIZE * 2 },
})
