import { Response, NextFunction } from 'express'
import { AuthRequest } from '../types'
import { verifyAccessToken } from '../services/jwt.service'
import { sendError } from '../utils/response'

export function authenticate(req: AuthRequest, res: Response, next: NextFunction): void {
  const header = req.headers.authorization
  if (!header?.startsWith('Bearer ')) {
    sendError(res, 'غير مصرح — يرجى تسجيل الدخول', 401)
    return
  }
  const token = header.slice(7)
  try {
    const payload = verifyAccessToken(token)
    req.user = { id: payload.id, email: payload.email, role: payload.role, plan: payload.plan }
    next()
  } catch {
    sendError(res, 'انتهت صلاحية الجلسة — يرجى تسجيل الدخول مجدداً', 401)
  }
}

export function requireAdmin(req: AuthRequest, res: Response, next: NextFunction): void {
  if (req.user?.role !== 'ADMIN') {
    sendError(res, 'هذا الإجراء يتطلب صلاحيات المدير', 403)
    return
  }
  next()
}
