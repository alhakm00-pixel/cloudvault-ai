import { Router } from 'express'
import {
  generateSubtitles, getSubtitles, getSubtitleFile,
  generateAISummary, searchInFile, smartSearch,
  chatWithFileContent, getAIStatus,
} from '../controllers/ai.controller'
import { authenticate } from '../middleware/auth.middleware'
import { apiLimiter } from '../middleware/ratelimit.middleware'

const router = Router()
router.use(authenticate as any)
router.use(apiLimiter)

// Smart search across all files
router.get('/search',                    smartSearch       as any)

// Per-file AI operations
router.get('/files/:id/status',          getAIStatus       as any)
router.post('/files/:id/subtitles',      generateSubtitles as any)
router.get('/files/:id/subtitles',       getSubtitles      as any)
router.get('/subtitles/:subtitleId/file',getSubtitleFile   as any)
router.post('/files/:id/summary',        generateAISummary as any)
router.get('/files/:id/search',          searchInFile      as any)
router.post('/files/:id/chat',           chatWithFileContent as any)

export default router
