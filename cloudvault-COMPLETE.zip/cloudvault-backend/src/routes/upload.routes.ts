import { Router } from 'express'
import {
  initUpload, uploadChunk, completeUpload,
  abortUpload, getUploadStatus, simpleUpload,
} from '../controllers/upload.controller'
import { authenticate } from '../middleware/auth.middleware'
import { uploadLimiter } from '../middleware/ratelimit.middleware'
import { chunkUpload, memUpload } from '../middleware/upload.middleware'

const router = Router()
router.use(authenticate)
router.use(uploadLimiter)

router.post('/init',             initUpload)
router.post('/chunk',            chunkUpload.single('chunk'), uploadChunk)
router.post('/complete',         completeUpload)
router.delete('/:sessionId',     abortUpload)
router.get('/:sessionId/status', getUploadStatus)
router.post('/simple',           memUpload.single('file'), simpleUpload)

export default router
