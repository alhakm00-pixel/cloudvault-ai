import { Router } from 'express'
import {
  listFiles, getFile, downloadFile, streamVideo,
  getPresignedUrl, updateFile, toggleStar,
  softDeleteFile, deleteFile, restoreFile,
  bulkDelete, getStorageStats,
} from '../controllers/file.controller'
import { authenticate } from '../middleware/auth.middleware'

const router = Router()
router.use(authenticate)

router.get('/stats',          getStorageStats)
router.get('/',               listFiles)
router.get('/:id',            getFile)
router.get('/:id/download',   downloadFile)
router.get('/:id/stream',     streamVideo)
router.get('/:id/presign',    getPresignedUrl)
router.patch('/:id',          updateFile)
router.patch('/:id/star',     toggleStar)
router.delete('/:id/soft',    softDeleteFile)
router.delete('/:id',         deleteFile)
router.patch('/:id/restore',  restoreFile)
router.post('/bulk-delete',   bulkDelete)

export default router
