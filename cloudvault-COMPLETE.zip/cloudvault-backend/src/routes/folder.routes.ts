import { Router } from 'express'
import {
  createFolder, listFolders, updateFolder,
  deleteFolder, toggleStarFolder,
} from '../controllers/folder.controller'
import { authenticate } from '../middleware/auth.middleware'

const router = Router()
router.use(authenticate)

router.get('/',           listFolders)
router.post('/',          createFolder)
router.patch('/:id',      updateFolder)
router.delete('/:id',     deleteFolder)
router.patch('/:id/star', toggleStarFolder)

export default router
