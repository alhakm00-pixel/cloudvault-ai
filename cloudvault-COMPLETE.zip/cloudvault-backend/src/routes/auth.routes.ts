import { Router } from 'express'
import {
  register, login, logout, refreshToken,
  getMe, updateProfile, changePassword,
  registerValidators, loginValidators,
} from '../controllers/auth.controller'
import { authenticate } from '../middleware/auth.middleware'
import { validate } from '../middleware/validate.middleware'
import { authLimiter } from '../middleware/ratelimit.middleware'

const router = Router()

// Public
router.post('/register', authLimiter, registerValidators, validate, register)
router.post('/login',    authLimiter, loginValidators,    validate, login)
router.post('/refresh',  authLimiter, refreshToken)

// Protected
router.use(authenticate)
router.post('/logout',            logout)
router.get('/me',                 getMe)
router.patch('/me',               updateProfile)
router.patch('/me/password',      changePassword)

export default router
