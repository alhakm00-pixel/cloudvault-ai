import { Router } from 'express'
import { getPreview, inlineFile, getThumbnail, publicPreview } from '../controllers/preview.controller'
import { authenticate } from '../middleware/auth.middleware'

const router = Router()

// Public share preview
router.get('/public/:token', publicPreview as any)

// Protected
router.use(authenticate as any)
router.get('/:id',           getPreview    as any)
router.get('/:id/inline',    inlineFile    as any)
router.get('/:id/thumbnail', getThumbnail  as any)

export default router
