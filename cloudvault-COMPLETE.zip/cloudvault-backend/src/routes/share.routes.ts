import { Router } from 'express'
import {
  createShareLink, getSharedFile, listShareLinks,
  revokeShareLink, downloadShared,
} from '../controllers/share.controller'
import { authenticate } from '../middleware/auth.middleware'

const router = Router()

// Public (no auth required)
router.get('/:token',          getSharedFile)
router.get('/:token/download', downloadShared)

// Protected
router.use(authenticate)
router.post('/files/:id/share',    createShareLink)
router.get('/me/links',            listShareLinks)
router.delete('/links/:shareId',   revokeShareLink)

export default router
