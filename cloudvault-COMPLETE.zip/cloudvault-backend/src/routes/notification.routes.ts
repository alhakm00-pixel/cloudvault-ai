import { Router } from 'express'
import {
  listNotifications, markAsRead, deleteNotification,
} from '../controllers/notification.controller'
import { authenticate } from '../middleware/auth.middleware'

const router = Router()
router.use(authenticate)

router.get('/',         listNotifications)
router.patch('/:id',    markAsRead)
router.delete('/:id',   deleteNotification)

export default router
