import { env } from '../config/env'
import { logger } from '../utils/logger'

// ─── Smart file search via AI embeddings (simplified) ────────────────────────
export async function semanticSearch(
  query: string,
  files: Array<{ id: string; name: string; tags: string[]; mimeType: string }>,
): Promise<Array<{ id: string; score: number; reason: string }>> {
  if (!env.OPENAI_API_KEY) {
    // Fallback: simple text match
    const q = query.toLowerCase()
    return files
      .filter(f => f.name.toLowerCase().includes(q) || f.tags.some(t => t.toLowerCase().includes(q)))
      .map(f => ({ id: f.id, score: 0.8, reason: `اسم الملف يحتوي على "${query}"` }))
  }

  const prompt = `أنت محرك بحث ذكي. المستخدم يبحث عن: "${query}"
قائمة الملفات:
${files.map((f, i) => `${i + 1}. "${f.name}" (${f.mimeType}) - وسوم: ${f.tags.join(', ')}`).join('\n')}

أعد JSON فقط بالشكل:
[{"id": "file_id", "score": 0.0-1.0, "reason": "سبب الصلة"}]
رتّب حسب الصلة. أعد فقط الملفات ذات الصلة (score > 0.3).`

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.2,
        response_format: { type: 'json_object' },
      }),
    })

    if (!response.ok) throw new Error('AI search failed')
    const data    = await response.json() as { choices: { message: { content: string } }[] }
    const parsed  = JSON.parse(data.choices[0]?.message?.content ?? '{"results":[]}')
    const results = Array.isArray(parsed) ? parsed : (parsed.results ?? [])

    // Map back to file IDs
    return results.map((r: any) => {
      const fileIndex = parseInt(r.id) - 1
      const file      = files[fileIndex]
      return file ? { id: file.id, score: r.score, reason: r.reason } : null
    }).filter(Boolean)
  } catch (err) {
    logger.error('semanticSearch error:', err)
    return []
  }
}

// ─── Auto-tag files using AI ──────────────────────────────────────────────────
export async function autoTagFile(
  fileName: string,
  mimeType: string,
  transcript?: string,
): Promise<string[]> {
  if (!env.OPENAI_API_KEY) {
    const ext = fileName.split('.').pop()?.toLowerCase() ?? ''
    const defaultTags: Record<string, string[]> = {
      mp4: ['فيديو', 'تسجيل'], mp3: ['صوت', 'موسيقى'],
      pdf: ['مستند', 'وثيقة'], jpg: ['صورة', 'مرئيات'],
      png: ['صورة', 'تصميم'], zip: ['ضغط', 'أرشيف'],
    }
    return defaultTags[ext] ?? ['ملف']
  }

  const context = transcript
    ? `النص: ${transcript.substring(0, 500)}`
    : `نوع الملف: ${mimeType}`

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'user',
          content: `اقترح 3-6 وسوم عربية مناسبة لهذا الملف:
اسم الملف: ${fileName}
${context}

أجب بـ JSON فقط: {"tags": ["وسم1", "وسم2", "وسم3"]}`,
        },
      ],
      temperature: 0.4,
      response_format: { type: 'json_object' },
    }),
  })

  if (!response.ok) return []
  const data   = await response.json() as { choices: { message: { content: string } }[] }
  const parsed = JSON.parse(data.choices[0]?.message?.content ?? '{"tags":[]}')
  return Array.isArray(parsed.tags) ? parsed.tags.slice(0, 6) : []
}

// ─── Detect file language ─────────────────────────────────────────────────────
export async function detectLanguage(text: string): Promise<{ language: string; confidence: number }> {
  if (!env.OPENAI_API_KEY) return { language: 'ar', confidence: 0.9 }

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'user',
          content: `حدّد لغة هذا النص. أجب بـ JSON فقط:
{"language": "ar/en/fr/...", "confidence": 0.0-1.0, "languageName": "العربية/English/..."}

النص: "${text.substring(0, 300)}"`,
        },
      ],
      response_format: { type: 'json_object' },
    }),
  })

  if (!response.ok) return { language: 'ar', confidence: 0.8 }
  const data   = await response.json() as { choices: { message: { content: string } }[] }
  const parsed = JSON.parse(data.choices[0]?.message?.content ?? '{}')
  return { language: parsed.language ?? 'ar', confidence: parsed.confidence ?? 0.8 }
}

// ─── Chat with file content (RAG-lite) ───────────────────────────────────────
export async function chatWithFile(
  question: string,
  transcript: string,
  fileName: string,
  history: Array<{ role: 'user' | 'assistant'; content: string }> = [],
): Promise<string> {
  if (!env.OPENAI_API_KEY) {
    return `هذا رد تجريبي على سؤالك: "${question}" عن الملف "${fileName}".`
  }

  const systemPrompt = `أنت مساعد ذكي يجيب على أسئلة المستخدم بناءً على محتوى الملف التالي:
الملف: ${fileName}
المحتوى:
${transcript.substring(0, 8000)}

قواعد:
- أجب بالعربية دائماً
- اذكر الوقت المحدد في الفيديو إذا كان سؤالاً عن فيديو
- إذا لم يكن الجواب في المحتوى، قل ذلك بوضوح
- كن موجزاً ودقيقاً`

  const messages = [
    { role: 'system' as const, content: systemPrompt },
    ...history.slice(-6), // Last 3 exchanges
    { role: 'user' as const, content: question },
  ]

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: 'gpt-4o', messages, temperature: 0.6 }),
  })

  if (!response.ok) throw new Error('Chat API error')
  const data = await response.json() as { choices: { message: { content: string } }[] }
  return data.choices[0]?.message?.content ?? 'عذراً، تعذّر توليد رد.'
}
