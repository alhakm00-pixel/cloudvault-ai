import { Response } from 'express'
import { Readable } from 'stream'
import { getObjectStream, headObject } from './r2.service'
import { logger } from '../utils/logger'

// ─── Parse Range header ───────────────────────────────────────────────────────
export function parseRange(rangeHeader: string, totalSize: number): { start: number; end: number } | null {
  const match = rangeHeader.match(/bytes=(\d+)-(\d*)/)
  if (!match) return null
  const start = parseInt(match[1])
  const end   = match[2] ? parseInt(match[2]) : totalSize - 1
  if (start >= totalSize || end >= totalSize || start > end) return null
  return { start, end }
}

// ─── Stream file with HTTP Range support ──────────────────────────────────────
export async function streamFile(
  res: Response,
  storageKey: string,
  mimeType: string,
  fileName: string,
  rangeHeader?: string,
  inline = false,
): Promise<void> {
  try {
    // Get file size first
    const head        = await headObject(storageKey)
    const totalSize   = head.ContentLength ?? 0
    const disposition = inline ? 'inline' : `attachment; filename*=UTF-8''${encodeURIComponent(fileName)}`

    res.setHeader('Accept-Ranges',       'bytes')
    res.setHeader('Content-Type',        mimeType)
    res.setHeader('Content-Disposition', disposition)
    res.setHeader('Cache-Control',       inline ? 'public, max-age=3600' : 'no-store')

    // ── Range request (video seek / partial) ─────────────────────────────────
    if (rangeHeader) {
      const range = parseRange(rangeHeader, totalSize)
      if (!range) {
        res.setHeader('Content-Range', `bytes */${totalSize}`)
        res.status(416).end()
        return
      }

      const chunkSize = range.end - range.start + 1
      const s3Range   = `bytes=${range.start}-${range.end}`

      const s3res = await getObjectStream(storageKey, s3Range)
      res.status(206)
      res.setHeader('Content-Length', chunkSize)
      res.setHeader('Content-Range',  `bytes ${range.start}-${range.end}/${totalSize}`)

      if (s3res.Body instanceof Readable) {
        s3res.Body.pipe(res)
        s3res.Body.on('error', (err) => {
          logger.error('Stream pipe error:', err)
          if (!res.headersSent) res.status(500).end()
        })
      } else {
        const bytes = await (s3res.Body as any).transformToByteArray()
        res.end(Buffer.from(bytes))
      }
      return
    }

    // ── Full file ─────────────────────────────────────────────────────────────
    const s3res = await getObjectStream(storageKey)
    if (totalSize) res.setHeader('Content-Length', totalSize)
    res.status(200)

    if (s3res.Body instanceof Readable) {
      s3res.Body.pipe(res)
      s3res.Body.on('error', (err) => {
        logger.error('Stream pipe error:', err)
        if (!res.headersSent) res.status(500).end()
      })
    } else {
      const bytes = await (s3res.Body as any).transformToByteArray()
      res.end(Buffer.from(bytes))
    }
  } catch (err) {
    logger.error('streamFile error:', err)
    if (!res.headersSent) {
      res.status(500).json({ success: false, message: 'فشل بث الملف' })
    }
  }
}

// ─── HLS-style adaptive streaming metadata ───────────────────────────────────
export function buildStreamManifest(fileId: string, baseUrl: string): string {
  return [
    '#EXTM3U',
    '#EXT-X-VERSION:3',
    `#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=854x480`,
    `${baseUrl}/api/v1/files/${fileId}/stream?quality=480p`,
    `#EXT-X-STREAM-INF:BANDWIDTH=1400000,RESOLUTION=1280x720`,
    `${baseUrl}/api/v1/files/${fileId}/stream?quality=720p`,
    `#EXT-X-STREAM-INF:BANDWIDTH=2800000,RESOLUTION=1920x1080`,
    `${baseUrl}/api/v1/files/${fileId}/stream?quality=1080p`,
  ].join('\n')
}
