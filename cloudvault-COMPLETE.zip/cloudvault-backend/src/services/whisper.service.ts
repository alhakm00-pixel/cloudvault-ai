import fs from 'fs'
import path from 'path'
import { exec } from 'child_process'
import { promisify } from 'util'
import { env } from '../config/env'
import { logger } from '../utils/logger'
import { uploadObject } from './r2.service'

const execAsync = promisify(exec)

// ─── SRT timestamp formatter ──────────────────────────────────────────────────
function secondsToSrt(s: number): string {
  const h   = Math.floor(s / 3600)
  const m   = Math.floor((s % 3600) / 60)
  const sec = Math.floor(s % 60)
  const ms  = Math.round((s % 1) * 1000)
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')},${String(ms).padStart(3,'0')}`
}

// ─── VTT timestamp formatter ──────────────────────────────────────────────────
function secondsToVtt(s: number): string {
  return secondsToSrt(s).replace(',', '.')
}

export interface SubtitleSegment {
  index:    number
  start:    number   // seconds
  end:      number
  text:     string
  textAr?:  string   // Arabic translation
}

export interface WhisperResult {
  language:     string
  duration:     number
  segments:     SubtitleSegment[]
  fullText:     string
  fullTextAr?:  string
  srtContent:   string
  vttContent:   string
  srtContentAr?: string
  vttContentAr?: string
}

// ─── Extract audio from video ─────────────────────────────────────────────────
export async function extractAudio(videoPath: string, outputPath: string): Promise<void> {
  await execAsync(
    `ffmpeg -y -i "${videoPath}" -vn -acodec pcm_s16le -ar 16000 -ac 1 "${outputPath}"`,
  )
  logger.info(`Audio extracted: ${outputPath}`)
}

// ─── Transcribe with OpenAI Whisper API ──────────────────────────────────────
export async function transcribeWithWhisper(
  audioPath: string,
  language = 'ar',
): Promise<{ segments: SubtitleSegment[]; fullText: string; detectedLanguage: string; duration: number }> {
  // Check file exists
  if (!fs.existsSync(audioPath)) throw new Error(`Audio file not found: ${audioPath}`)

  const fileSize = fs.statSync(audioPath).size
  logger.info(`Transcribing ${path.basename(audioPath)} (${(fileSize / 1e6).toFixed(1)}MB)`)

  if (!env.OPENAI_API_KEY) {
    logger.warn('OpenAI key not set — returning demo transcript')
    return generateDemoTranscript()
  }

  // OpenAI Whisper supports up to 25MB — split if larger
  if (fileSize > 24 * 1024 * 1024) {
    return transcribeLargeFile(audioPath, language)
  }

  const formData = new FormData()
  const blob     = new Blob([fs.readFileSync(audioPath)], { type: 'audio/wav' })
  formData.append('file',             blob,           path.basename(audioPath))
  formData.append('model',            'whisper-1')
  formData.append('response_format',  'verbose_json')
  formData.append('timestamp_granularities[]', 'segment')
  if (language && language !== 'auto') formData.append('language', language)

  const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}` },
    body: formData,
  })

  if (!response.ok) {
    const err = await response.text()
    throw new Error(`Whisper API error: ${err}`)
  }

  const data = await response.json() as {
    text: string
    language: string
    duration: number
    segments: Array<{ id: number; start: number; end: number; text: string }>
  }

  const segments: SubtitleSegment[] = data.segments.map((s, i) => ({
    index: i + 1,
    start: s.start,
    end:   s.end,
    text:  s.text.trim(),
  }))

  logger.info(`Whisper transcribed: ${segments.length} segments, lang=${data.language}`)
  return {
    segments,
    fullText:          data.text,
    detectedLanguage:  data.language,
    duration:          data.duration,
  }
}

// ─── Handle large files by splitting ─────────────────────────────────────────
async function transcribeLargeFile(
  audioPath: string,
  language: string,
): Promise<{ segments: SubtitleSegment[]; fullText: string; detectedLanguage: string; duration: number }> {
  const tmpDir   = '/tmp/cv-whisper-chunks'
  fs.mkdirSync(tmpDir, { recursive: true })

  // Split into 20-min chunks
  const chunkSec   = 1200
  const { stdout } = await execAsync(`ffprobe -v quiet -show_entries format=duration -of csv=p=0 "${audioPath}"`)
  const totalDur   = parseFloat(stdout.trim())
  const numChunks  = Math.ceil(totalDur / chunkSec)

  const allSegments: SubtitleSegment[] = []
  let   detectedLanguage = language
  let   globalIndex      = 1
  let   fullText         = ''

  for (let i = 0; i < numChunks; i++) {
    const start    = i * chunkSec
    const chunkOut = path.join(tmpDir, `chunk_${i}.wav`)

    await execAsync(
      `ffmpeg -y -i "${audioPath}" -ss ${start} -t ${chunkSec} "${chunkOut}"`,
    )

    const result = await transcribeWithWhisper(chunkOut, language)
    detectedLanguage = result.detectedLanguage

    // Offset timestamps
    result.segments.forEach((seg) => {
      allSegments.push({
        ...seg,
        index: globalIndex++,
        start: seg.start + start,
        end:   seg.end   + start,
      })
    })
    fullText += result.fullText + ' '

    fs.unlinkSync(chunkOut)
  }

  return { segments: allSegments, fullText: fullText.trim(), detectedLanguage, duration: totalDur }
}

// ─── Translate segments to Arabic via GPT-4o ─────────────────────────────────
export async function translateToArabic(segments: SubtitleSegment[]): Promise<SubtitleSegment[]> {
  if (!env.OPENAI_API_KEY) {
    logger.warn('OpenAI key not set — returning demo translation')
    return segments.map(s => ({
      ...s,
      textAr: `[ترجمة عربية]: ${s.text}`,
    }))
  }

  // Batch translate in groups of 30
  const BATCH = 30
  const translated: SubtitleSegment[] = [...segments]

  for (let i = 0; i < segments.length; i += BATCH) {
    const batch = segments.slice(i, i + BATCH)
    const lines = batch.map((s, j) => `${j + 1}|${s.text}`).join('\n')

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization:  `Bearer ${env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `أنت مترجم محترف. ترجم كل سطر إلى العربية الفصحى بدقة، 
مع الحفاظ على المعنى والسياق. رقم السطر متبوعاً بـ | ثم الترجمة.
حافظ على نفس التنسيق: رقم|ترجمة`,
          },
          { role: 'user', content: lines },
        ],
        temperature: 0.3,
      }),
    })

    if (!response.ok) {
      logger.error('Translation API error')
      continue
    }

    const data       = await response.json() as { choices: { message: { content: string } }[] }
    const resultText = data.choices[0]?.message?.content ?? ''

    resultText.split('\n').forEach((line) => {
      const [numStr, ...rest] = line.split('|')
      const num = parseInt(numStr?.trim() ?? '')
      if (!isNaN(num) && rest.length) {
        const globalIdx = i + num - 1
        if (globalIdx < translated.length) {
          translated[globalIdx] = { ...translated[globalIdx], textAr: rest.join('|').trim() }
        }
      }
    })

    logger.debug(`Translated batch ${Math.floor(i / BATCH) + 1}/${Math.ceil(segments.length / BATCH)}`)
  }

  return translated
}

// ─── Generate SRT from segments ───────────────────────────────────────────────
export function generateSrt(segments: SubtitleSegment[], useArabic = false): string {
  return segments.map((seg) => {
    const text = useArabic ? (seg.textAr ?? seg.text) : seg.text
    return `${seg.index}\n${secondsToSrt(seg.start)} --> ${secondsToSrt(seg.end)}\n${text}\n`
  }).join('\n')
}

// ─── Generate WebVTT from segments ───────────────────────────────────────────
export function generateVtt(segments: SubtitleSegment[], useArabic = false): string {
  const header = 'WEBVTT\n\n'
  const body   = segments.map((seg) => {
    const text = useArabic ? (seg.textAr ?? seg.text) : seg.text
    return `${secondsToVtt(seg.start)} --> ${secondsToVtt(seg.end)}\n${text}\n`
  }).join('\n')
  return header + body
}

// ─── Upload subtitle file to R2 ───────────────────────────────────────────────
export async function uploadSubtitle(
  content: string,
  userId: string,
  fileId: string,
  language: string,
  format: 'srt' | 'vtt',
): Promise<string> {
  const key = `users/${userId}/subtitles/${fileId}/${language}.${format}`
  const url = await uploadObject(key, Buffer.from(content, 'utf-8'), 'text/plain; charset=utf-8')
  return url
}

// ─── AI Video Summary ─────────────────────────────────────────────────────────
export async function generateSummary(
  fullText: string,
  fileName: string,
  language = 'ar',
): Promise<{ summary: string; keyPoints: string[]; topics: string[] }> {
  if (!env.OPENAI_API_KEY) {
    return {
      summary:    'هذا ملخص تجريبي للمحتوى الصوتي/المرئي.',
      keyPoints:  ['النقطة الأولى', 'النقطة الثانية', 'النقطة الثالثة'],
      topics:     ['موضوع 1', 'موضوع 2'],
    }
  }

  const prompt = language === 'ar'
    ? `قدّم ملخصاً شاملاً للمحتوى التالي باللغة العربية:
       العنوان: ${fileName}
       النص: ${fullText.substring(0, 6000)}
       
       أجب بتنسيق JSON فقط:
       {
         "summary": "ملخص شامل في 3-4 جمل",
         "keyPoints": ["نقطة 1", "نقطة 2", "نقطة 3", "نقطة 4", "نقطة 5"],
         "topics": ["موضوع 1", "موضوع 2", "موضوع 3"]
       }`
    : `Provide a comprehensive summary of the following content:
       Title: ${fileName}
       Text: ${fullText.substring(0, 6000)}
       
       Respond in JSON only:
       {
         "summary": "3-4 sentence comprehensive summary",
         "keyPoints": ["point 1", "point 2", "point 3", "point 4", "point 5"],
         "topics": ["topic 1", "topic 2", "topic 3"]
       }`

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'gpt-4o',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.5,
      response_format: { type: 'json_object' },
    }),
  })

  if (!response.ok) throw new Error('Summary API error')

  const data = await response.json() as { choices: { message: { content: string } }[] }
  const parsed = JSON.parse(data.choices[0]?.message?.content ?? '{}')

  return {
    summary:    parsed.summary    ?? '',
    keyPoints:  parsed.keyPoints  ?? [],
    topics:     parsed.topics     ?? [],
  }
}

// ─── Smart search in transcript ───────────────────────────────────────────────
export async function searchInTranscript(
  segments: SubtitleSegment[],
  query: string,
): Promise<{ segment: SubtitleSegment; relevance: number; highlight: string }[]> {
  const q = query.toLowerCase()
  const results: { segment: SubtitleSegment; relevance: number; highlight: string }[] = []

  segments.forEach((seg) => {
    const text   = seg.text.toLowerCase()
    const textAr = (seg.textAr ?? '').toLowerCase()

    if (text.includes(q) || textAr.includes(q)) {
      // Simple relevance: 1 if exact match, 0.5 if partial
      const relevance = text === q || textAr === q ? 1 : 0.7
      const sourceText = text.includes(q) ? seg.text : (seg.textAr ?? seg.text)
      const idx  = sourceText.toLowerCase().indexOf(q)
      const highlight = sourceText.substring(Math.max(0, idx - 20), idx + q.length + 20)
      results.push({ segment: seg, relevance, highlight })
    }
  })

  return results.sort((a, b) => b.relevance - a.relevance)
}

// ─── Demo transcript for testing without API key ─────────────────────────────
function generateDemoTranscript(): { segments: SubtitleSegment[]; fullText: string; detectedLanguage: string; duration: number } {
  const segments: SubtitleSegment[] = [
    { index: 1, start: 0,    end: 4.5,  text: 'Hello and welcome to this video tutorial.' },
    { index: 2, start: 4.5,  end: 9.2,  text: 'Today we will learn about cloud storage and AI.' },
    { index: 3, start: 9.2,  end: 15.0, text: 'CloudVault AI is a powerful platform for storing your files.' },
    { index: 4, start: 15.0, end: 20.8, text: 'It features automatic subtitle generation using Whisper AI.' },
    { index: 5, start: 20.8, end: 27.3, text: 'You can search within video content using smart AI search.' },
    { index: 6, start: 27.3, end: 33.1, text: 'The platform supports Arabic translation for all content.' },
    { index: 7, start: 33.1, end: 40.0, text: 'Thank you for watching. Don\'t forget to like and subscribe!' },
  ]
  return {
    segments,
    fullText: segments.map(s => s.text).join(' '),
    detectedLanguage: 'en',
    duration: 40,
  }
}
