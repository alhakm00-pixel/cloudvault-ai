import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import prisma from '../config/database'
import {
  uploadObject, deleteObject, buildStorageKey, buildPublicUrl,
  createMultipartUpload, uploadPart, completeMultipartUpload,
} from './r2.service'
import {
  generateImageThumbnail, generateVideoThumbnail,
  generatePdfThumbnail, generatePlaceholderThumbnail,
  compressImage, getVideoMetadata,
} from './thumbnail.service'
import { logger } from '../utils/logger'
import { env } from '../config/env'

// ─── Process file after upload ────────────────────────────────────────────────
// Called after a file lands in temp storage or memory
export async function processFile(
  fileId: string,
  filePath: string | null, // null = buffer was already uploaded
  buffer: Buffer | null,
  originalName: string,
  mimeType: string,
  userId: string,
): Promise<{ storageUrl: string; thumbnailUrl?: string; width?: number; height?: number; duration?: number }> {
  const isImage  = mimeType.startsWith('image/')
  const isVideo  = mimeType.startsWith('video/')
  const isPdf    = mimeType === 'application/pdf'
  const isAudio  = mimeType.startsWith('audio/')

  let finalBuffer: Buffer
  if (buffer) {
    finalBuffer = buffer
  } else if (filePath && fs.existsSync(filePath)) {
    finalBuffer = fs.readFileSync(filePath)
  } else {
    throw new Error('No file data provided')
  }

  const storageKey = buildStorageKey(userId, originalName)
  let   uploadBuffer = finalBuffer
  let   uploadMime   = mimeType
  let   width: number | undefined
  let   height: number | undefined
  let   duration: number | undefined
  let   thumbnailUrl: string | undefined

  // ── Image: compress + generate thumbnail ──────────────────────────────────
  if (isImage) {
    try {
      const compressed = await compressImage(finalBuffer, mimeType, { quality: 85 })
      uploadBuffer = compressed.buffer
      uploadMime   = compressed.mimeType
      width        = compressed.width
      height       = compressed.height

      const thumb = await generateImageThumbnail(finalBuffer, userId, fileId, mimeType)
      thumbnailUrl  = thumb.url

      await prisma.file.update({
        where: { id: fileId },
        data:  { thumbnailKey: thumb.key, thumbnailUrl: thumb.url, width, height },
      })
    } catch (err) {
      logger.warn(`Image processing failed for ${fileId}:`, err)
    }
  }

  // ── Video: extract thumbnail + metadata ───────────────────────────────────
  if (isVideo && filePath) {
    try {
      const meta = await getVideoMetadata(filePath)
      width    = meta.width
      height   = meta.height
      duration = meta.duration

      const thumb = await generateVideoThumbnail(filePath, userId, fileId)
      thumbnailUrl = thumb.url

      await prisma.file.update({
        where: { id: fileId },
        data:  { thumbnailKey: thumb.key, thumbnailUrl: thumb.url, width, height, duration },
      })
    } catch (err) {
      logger.warn(`Video processing failed for ${fileId}:`, err)
    }
  }

  // ── PDF: thumbnail from first page ────────────────────────────────────────
  if (isPdf) {
    try {
      const thumb = await generatePdfThumbnail(finalBuffer, userId, fileId)
      thumbnailUrl = thumb.url
      await prisma.file.update({
        where: { id: fileId },
        data:  { thumbnailKey: thumb.key, thumbnailUrl: thumb.url },
      })
    } catch (err) {
      logger.warn(`PDF thumbnail failed for ${fileId}:`, err)
      // Fallback placeholder
      const placeholder = await generatePlaceholderThumbnail('pdf')
      const thumbKey    = `users/${userId}/thumbnails/${fileId}.webp`
      thumbnailUrl      = await uploadObject(thumbKey, placeholder, 'image/webp')
      await prisma.file.update({
        where: { id: fileId },
        data:  { thumbnailKey: thumbKey, thumbnailUrl },
      })
    }
  }

  // ── Audio / other: placeholder thumbnail ─────────────────────────────────
  if (isAudio || (!isImage && !isVideo && !isPdf)) {
    try {
      const type        = isAudio ? 'audio' : getExtType(originalName)
      const placeholder = await generatePlaceholderThumbnail(type)
      const thumbKey    = `users/${userId}/thumbnails/${fileId}.webp`
      thumbnailUrl      = await uploadObject(thumbKey, placeholder, 'image/webp')
      await prisma.file.update({
        where: { id: fileId },
        data:  { thumbnailKey: thumbKey, thumbnailUrl },
      })
    } catch (err) {
      logger.warn(`Placeholder thumbnail failed for ${fileId}:`, err)
    }
  }

  // ── Upload final file to R2 ───────────────────────────────────────────────
  const checksum = crypto.createHash('md5').update(uploadBuffer).digest('hex')
  const url      = await uploadObject(storageKey, uploadBuffer, uploadMime, {
    'original-name': encodeURIComponent(originalName),
    'user-id':       userId,
    'file-id':       fileId,
    'checksum':      checksum,
  })

  // Update file record
  await prisma.file.update({
    where: { id: fileId },
    data:  {
      storageKey,
      storageUrl: url,
      status:     'READY',
      checksum,
      ...(width    && { width }),
      ...(height   && { height }),
      ...(duration && { duration }),
    },
  })

  // Clean up temp file
  if (filePath && fs.existsSync(filePath)) {
    fs.unlink(filePath, () => {})
  }

  logger.info(`File processed: ${fileId} → ${storageKey}`)
  return { storageUrl: url, thumbnailUrl, width, height, duration }
}

function getExtType(name: string): string {
  const ext = path.extname(name).slice(1).toLowerCase()
  const map: Record<string, string> = {
    pdf: 'pdf', zip: 'zip', rar: 'zip', '7z': 'zip',
    doc: 'doc', docx: 'doc', xls: 'xls', xlsx: 'xls',
    ppt: 'ppt', pptx: 'ppt', mp3: 'audio', wav: 'audio',
  }
  return map[ext] ?? 'default'
}

// ─── Delete file + all its assets from R2 ────────────────────────────────────
export async function deleteFileAssets(storageKey: string, thumbnailKey?: string | null): Promise<void> {
  const tasks = [deleteObject(storageKey).catch((e) => logger.warn('R2 delete failed:', e))]
  if (thumbnailKey) tasks.push(deleteObject(thumbnailKey).catch(() => {}))
  await Promise.all(tasks)
}

// ─── Get signed preview URL ───────────────────────────────────────────────────
export async function getPreviewData(
  fileId: string,
  userId: string,
): Promise<{ type: string; url: string; mimeType: string; thumbnailUrl?: string }> {
  const file = await prisma.file.findFirst({
    where: { id: fileId, userId, deletedAt: null },
    select: { mimeType: true, storageKey: true, storageUrl: true, thumbnailUrl: true, status: true },
  })
  if (!file || file.status !== 'READY') throw new Error('File not available')

  const { presignedDownloadUrl } = await import('./r2.service')
  const url = await presignedDownloadUrl(file.storageKey, 7200) // 2-hour link

  let type = 'download'
  if (file.mimeType.startsWith('image/'))        type = 'image'
  else if (file.mimeType.startsWith('video/'))   type = 'video'
  else if (file.mimeType.startsWith('audio/'))   type = 'audio'
  else if (file.mimeType === 'application/pdf')  type = 'pdf'
  else if (file.mimeType.startsWith('text/'))    type = 'text'

  return { type, url, mimeType: file.mimeType, thumbnailUrl: file.thumbnailUrl ?? undefined }
}

// ─── Quota check ─────────────────────────────────────────────────────────────
export async function checkQuota(userId: string, fileSize: bigint): Promise<{ allowed: boolean; remaining: bigint }> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { storageUsed: true, storageTotal: true },
  })
  if (!user) return { allowed: false, remaining: BigInt(0) }
  const remaining = user.storageTotal - user.storageUsed
  return { allowed: remaining >= fileSize, remaining }
}
