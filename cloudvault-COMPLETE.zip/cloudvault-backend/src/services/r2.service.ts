import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
  CreateMultipartUploadCommand,
  UploadPartCommand,
  CompleteMultipartUploadCommand,
  AbortMultipartUploadCommand,
  ListPartsCommand,
} from '@aws-sdk/client-s3'
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'
import { Upload } from '@aws-sdk/lib-storage'
import { Readable } from 'stream'
import { env } from '../config/env'
import { logger } from '../utils/logger'

// ─── Initialise R2 client ────────────────────────────────────────────────────
const r2 = new S3Client({
  region: 'auto',
  endpoint: env.R2_ENDPOINT,
  credentials: {
    accessKeyId:     env.R2_ACCESS_KEY_ID,
    secretAccessKey: env.R2_SECRET_ACCESS_KEY,
  },
})

const BUCKET = env.R2_BUCKET_NAME

// ─── Simple (single-part) upload ────────────────────────────────────────────
export async function uploadObject(
  key: string,
  body: Buffer | Readable,
  mimeType: string,
  metadata: Record<string, string> = {},
): Promise<string> {
  await r2.send(new PutObjectCommand({
    Bucket: BUCKET,
    Key:    key,
    Body:   body,
    ContentType: mimeType,
    Metadata: metadata,
  }))
  logger.info(`R2 upload complete: ${key}`)
  return buildPublicUrl(key)
}

// ─── Multipart upload helpers ────────────────────────────────────────────────
export async function createMultipartUpload(key: string, mimeType: string): Promise<string> {
  const res = await r2.send(new CreateMultipartUploadCommand({
    Bucket: BUCKET, Key: key, ContentType: mimeType,
  }))
  if (!res.UploadId) throw new Error('Failed to create multipart upload')
  return res.UploadId
}

export async function uploadPart(
  key: string,
  uploadId: string,
  partNumber: number,
  body: Buffer,
): Promise<{ ETag: string; PartNumber: number }> {
  const res = await r2.send(new UploadPartCommand({
    Bucket: BUCKET, Key: key, UploadId: uploadId,
    PartNumber: partNumber, Body: body,
  }))
  if (!res.ETag) throw new Error(`Failed to upload part ${partNumber}`)
  return { ETag: res.ETag, PartNumber: partNumber }
}

export async function completeMultipartUpload(
  key: string,
  uploadId: string,
  parts: { ETag: string; PartNumber: number }[],
): Promise<string> {
  await r2.send(new CompleteMultipartUploadCommand({
    Bucket: BUCKET, Key: key, UploadId: uploadId,
    MultipartUpload: { Parts: parts.sort((a, b) => a.PartNumber - b.PartNumber) },
  }))
  logger.info(`R2 multipart complete: ${key}`)
  return buildPublicUrl(key)
}

export async function abortMultipartUpload(key: string, uploadId: string): Promise<void> {
  await r2.send(new AbortMultipartUploadCommand({
    Bucket: BUCKET, Key: key, UploadId: uploadId,
  }))
}

// ─── Download / stream ────────────────────────────────────────────────────────
export async function getObjectStream(key: string, range?: string) {
  const cmd: GetObjectCommand = new GetObjectCommand({
    Bucket: BUCKET, Key: key,
    ...(range ? { Range: range } : {}),
  })
  return r2.send(cmd)
}

export async function getObjectBuffer(key: string): Promise<Buffer> {
  const res = await r2.send(new GetObjectCommand({ Bucket: BUCKET, Key: key }))
  if (!res.Body) throw new Error('Empty object body')
  return Buffer.from(await res.Body.transformToByteArray())
}

// ─── Metadata ────────────────────────────────────────────────────────────────
export async function headObject(key: string) {
  return r2.send(new HeadObjectCommand({ Bucket: BUCKET, Key: key }))
}

export async function objectExists(key: string): Promise<boolean> {
  try {
    await headObject(key)
    return true
  } catch {
    return false
  }
}

// ─── Delete ──────────────────────────────────────────────────────────────────
export async function deleteObject(key: string): Promise<void> {
  await r2.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }))
  logger.info(`R2 delete: ${key}`)
}

// ─── Presigned URLs ──────────────────────────────────────────────────────────
export async function presignedDownloadUrl(key: string, expiresIn = 3600): Promise<string> {
  const cmd = new GetObjectCommand({ Bucket: BUCKET, Key: key })
  return getSignedUrl(r2, cmd, { expiresIn })
}

export async function presignedUploadUrl(
  key: string, mimeType: string, expiresIn = 900,
): Promise<string> {
  const cmd = new PutObjectCommand({ Bucket: BUCKET, Key: key, ContentType: mimeType })
  return getSignedUrl(r2, cmd, { expiresIn })
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
export function buildPublicUrl(key: string): string {
  return `${env.R2_PUBLIC_URL}/${key}`
}

export function buildStorageKey(userId: string, fileName: string): string {
  const ts  = Date.now()
  const ext = fileName.split('.').pop() ?? ''
  const safe = fileName.replace(/[^a-zA-Z0-9._-]/g, '_').substring(0, 80)
  return `users/${userId}/files/${ts}-${safe}`
}

export function buildThumbnailKey(userId: string, fileId: string): string {
  return `users/${userId}/thumbnails/${fileId}.webp`
}
