import sharp from 'sharp'
import path from 'path'
import fs from 'fs'
import { exec } from 'child_process'
import { promisify } from 'util'
import { uploadObject, buildThumbnailKey, deleteObject } from './r2.service'
import { logger } from '../utils/logger'

const execAsync = promisify(exec)

export interface ThumbnailResult {
  key: string
  url: string
  width: number
  height: number
}

// ─── Image thumbnail ──────────────────────────────────────────────────────────
export async function generateImageThumbnail(
  inputBuffer: Buffer,
  userId: string,
  fileId: string,
  mimeType: string,
): Promise<ThumbnailResult> {
  const key = buildThumbnailKey(userId, fileId)

  // Resize to max 400×400, convert to WebP
  const webp = await sharp(inputBuffer)
    .resize(400, 400, { fit: 'inside', withoutEnlargement: true })
    .webp({ quality: 80 })
    .toBuffer()

  const meta = await sharp(webp).metadata()
  const url  = await uploadObject(key, webp, 'image/webp', { source: 'thumbnail' })

  logger.info(`Thumbnail generated: ${key}`)
  return { key, url, width: meta.width ?? 400, height: meta.height ?? 400 }
}

// ─── Video thumbnail (ffmpeg) ─────────────────────────────────────────────────
export async function generateVideoThumbnail(
  videoPath: string,
  userId: string,
  fileId: string,
): Promise<ThumbnailResult> {
  const tmpOut = path.join('/tmp', `thumb_${fileId}.jpg`)
  const key    = buildThumbnailKey(userId, fileId)

  try {
    // Extract frame at 5 seconds (or first frame if shorter)
    await execAsync(
      `ffmpeg -y -i "${videoPath}" -ss 00:00:05 -vframes 1 -vf "scale=400:-1" "${tmpOut}" 2>/dev/null || ` +
      `ffmpeg -y -i "${videoPath}" -vframes 1 -vf "scale=400:-1" "${tmpOut}"`,
    )

    const buffer = fs.readFileSync(tmpOut)

    // Convert to WebP
    const webp  = await sharp(buffer).webp({ quality: 75 }).toBuffer()
    const meta  = await sharp(webp).metadata()
    const url   = await uploadObject(key, webp, 'image/webp', { source: 'video-thumbnail' })

    logger.info(`Video thumbnail generated: ${key}`)
    return { key, url, width: meta.width ?? 400, height: meta.height ?? 225 }
  } finally {
    if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut)
  }
}

// ─── PDF thumbnail (first page preview) ──────────────────────────────────────
export async function generatePdfThumbnail(
  pdfBuffer: Buffer,
  userId: string,
  fileId: string,
): Promise<ThumbnailResult> {
  const key = buildThumbnailKey(userId, fileId)

  // Use sharp to handle the first page image conversion
  // (requires poppler-utils or ImageMagick in production)
  const webp = await sharp(pdfBuffer, { page: 0 })
    .resize(400, 565, { fit: 'inside' })
    .webp({ quality: 75 })
    .toBuffer()
    .catch(() => generatePlaceholderThumbnail('pdf'))

  const meta = await sharp(webp).metadata()
  const url  = await uploadObject(key, webp, 'image/webp', { source: 'pdf-thumbnail' })

  return { key, url, width: meta.width ?? 400, height: meta.height ?? 565 }
}

// ─── Placeholder SVG thumbnail ────────────────────────────────────────────────
export async function generatePlaceholderThumbnail(type: string): Promise<Buffer> {
  const icons: Record<string, string> = {
    pdf:   '📄', video: '🎬', audio: '🎵', zip: '📦',
    doc:   '📝', xls:  '📊', ppt:  '📑', default: '📁',
  }
  const icon = icons[type] ?? icons.default
  const color = {
    pdf: '#ef4444', video: '#8b5cf6', audio: '#10b981',
    zip: '#f59e0b', doc: '#3b82f6', default: '#6366f1',
  }[type] ?? '#6366f1'

  const svg = `<svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:${color};stop-opacity:0.3"/>
        <stop offset="100%" style="stop-color:#1e1b4b;stop-opacity:1"/>
      </linearGradient>
    </defs>
    <rect width="400" height="300" fill="url(#g)" rx="12"/>
    <text x="200" y="160" font-size="80" text-anchor="middle" dominant-baseline="middle">${icon}</text>
  </svg>`

  return sharp(Buffer.from(svg)).webp({ quality: 80 }).toBuffer()
}

// ─── Compress image for storage ───────────────────────────────────────────────
export async function compressImage(
  inputBuffer: Buffer,
  mimeType: string,
  options: { maxWidth?: number; maxHeight?: number; quality?: number } = {},
): Promise<{ buffer: Buffer; mimeType: string; width: number; height: number; savedBytes: number }> {
  const { maxWidth = 4096, maxHeight = 4096, quality = 85 } = options
  const original = inputBuffer.length

  let pipeline = sharp(inputBuffer).rotate() // auto-rotate from EXIF

  const meta = await sharp(inputBuffer).metadata()
  const w = meta.width ?? 0
  const h = meta.height ?? 0

  // Only resize if larger than max
  if (w > maxWidth || h > maxHeight) {
    pipeline = pipeline.resize(maxWidth, maxHeight, { fit: 'inside', withoutEnlargement: true })
  }

  // Convert to WebP for best compression
  const compressed = await pipeline.webp({ quality }).toBuffer()
  const compMeta   = await sharp(compressed).metadata()

  logger.debug(`Image compressed: ${original} → ${compressed.length} bytes (${Math.round((1 - compressed.length / original) * 100)}% saved)`)

  return {
    buffer: compressed,
    mimeType: 'image/webp',
    width:  compMeta.width  ?? w,
    height: compMeta.height ?? h,
    savedBytes: original - compressed.length,
  }
}

// ─── Get video metadata (duration, resolution) ───────────────────────────────
export async function getVideoMetadata(videoPath: string): Promise<{ duration: number; width: number; height: number }> {
  try {
    const { stdout } = await execAsync(
      `ffprobe -v quiet -print_format json -show_streams "${videoPath}"`,
    )
    const data    = JSON.parse(stdout)
    const stream  = data.streams?.find((s: any) => s.codec_type === 'video') ?? {}
    const duration = parseFloat(stream.duration ?? '0')
    return {
      duration: Math.round(duration),
      width:    parseInt(stream.width  ?? '0'),
      height:   parseInt(stream.height ?? '0'),
    }
  } catch {
    return { duration: 0, width: 0, height: 0 }
  }
}
