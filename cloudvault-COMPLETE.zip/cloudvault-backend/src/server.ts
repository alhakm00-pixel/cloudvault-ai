import 'dotenv/config'
import express, { Request, Response, NextFunction } from 'express'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'
import compression from 'compression'
import { createServer } from 'http'
import { Server as SocketServer } from 'socket.io'
import path from 'path'
import fs from 'fs'

import { env } from './config/env'
import { logger } from './utils/logger'
import prisma from './config/database'
import { apiLimiter } from './middleware/ratelimit.middleware'

// ─── Routes ───────────────────────────────────────────────────────────────────
import authRoutes         from './routes/auth.routes'
import uploadRoutes       from './routes/upload.routes'
import fileRoutes         from './routes/file.routes'
import shareRoutes        from './routes/share.routes'
import folderRoutes       from './routes/folder.routes'
import notificationRoutes from './routes/notification.routes'
import previewRoutes       from './routes/preview.routes'
import aiRoutes            from './routes/ai.routes'

// ─── Ensure temp upload dir ──────────────────────────────────────────────────
fs.mkdirSync(env.UPLOAD_TEMP_DIR, { recursive: true })
fs.mkdirSync('logs', { recursive: true })

// ─── Express app ─────────────────────────────────────────────────────────────
const app  = express()
const http = createServer(app)

// ─── Socket.IO (upload progress) ─────────────────────────────────────────────
export const io = new SocketServer(http, {
  cors: { origin: env.FRONTEND_URL, methods: ['GET', 'POST'] },
  path: '/socket.io',
})

io.on('connection', (socket) => {
  logger.info(`Socket connected: ${socket.id}`)

  socket.on('join:upload', (sessionId: string) => {
    socket.join(`upload:${sessionId}`)
    logger.debug(`Socket ${socket.id} joined upload room: ${sessionId}`)
  })

  socket.on('disconnect', () => {
    logger.info(`Socket disconnected: ${socket.id}`)
  })
})

// ─── Global middleware ────────────────────────────────────────────────────────
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: false,
}))

app.use(cors({
  origin:      env.FRONTEND_URL,
  credentials: true,
  methods:     ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Range'],
  exposedHeaders: ['Content-Range', 'Accept-Ranges', 'Content-Length'],
}))

app.use(compression())
app.use(express.json({ limit: '50mb' }))
app.use(express.urlencoded({ extended: true, limit: '50mb' }))

// HTTP logger (dev)
if (env.NODE_ENV === 'development') {
  app.use(morgan('dev'))
} else {
  app.use(morgan('combined', {
    stream: { write: (msg) => logger.http(msg.trim()) },
  }))
}

// ─── Rate limiting ────────────────────────────────────────────────────────────
app.use(env.API_PREFIX, apiLimiter)

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', async (_req: Request, res: Response) => {
  try {
    await prisma.$queryRaw`SELECT 1`
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      env: env.NODE_ENV,
    })
  } catch {
    res.status(503).json({ status: 'error', message: 'قاعدة البيانات غير متاحة' })
  }
})

// ─── API routes ───────────────────────────────────────────────────────────────
app.use(`${env.API_PREFIX}/auth`,          authRoutes)
app.use(`${env.API_PREFIX}/uploads`,       uploadRoutes)
app.use(`${env.API_PREFIX}/files`,         fileRoutes)
app.use(`${env.API_PREFIX}/share`,         shareRoutes)
app.use(`${env.API_PREFIX}/folders`,       folderRoutes)
app.use(`${env.API_PREFIX}/notifications`, notificationRoutes)
app.use(`${env.API_PREFIX}/preview`,       previewRoutes)
app.use(`${env.API_PREFIX}/ai`,            aiRoutes)

// ─── 404 ─────────────────────────────────────────────────────────────────────
app.use((_req: Request, res: Response) => {
  res.status(404).json({ success: false, message: 'المسار غير موجود' })
})

// ─── Global error handler ─────────────────────────────────────────────────────
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  logger.error(`Unhandled error: ${err.message}`, { stack: err.stack })
  res.status(500).json({
    success: false,
    message: 'حدث خطأ داخلي في الخادم',
    ...(env.NODE_ENV === 'development' && { error: err.message, stack: err.stack }),
  })
})

// ─── Start server ─────────────────────────────────────────────────────────────
const PORT = env.PORT

http.listen(PORT, async () => {
  try {
    await prisma.$connect()
    logger.info(`✅  Database connected`)
  } catch (err) {
    logger.error('❌  Database connection failed:', err)
  }

  logger.info(`🚀  CloudVault API running on http://localhost:${PORT}`)
  logger.info(`📋  API docs: http://localhost:${PORT}${env.API_PREFIX}`)
  logger.info(`🌍  Environment: ${env.NODE_ENV}`)
})

// ─── Graceful shutdown ────────────────────────────────────────────────────────
const shutdown = async (signal: string) => {
  logger.info(`${signal} received — shutting down gracefully`)
  http.close(() => {
    prisma.$disconnect().then(() => {
      logger.info('Server closed')
      process.exit(0)
    })
  })
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT',  () => shutdown('SIGINT'))

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Promise Rejection:', reason)
})

process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception:', err)
  process.exit(1)
})

export default app
