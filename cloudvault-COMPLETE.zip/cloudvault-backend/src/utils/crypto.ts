import crypto from 'crypto'
import { promisify } from 'util'

export function generateToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex')
}

export async function hashPassword(password: string): Promise<string> {
  const bcrypt = await import('bcryptjs')
  return bcrypt.hash(password, 12)
}

export async function comparePassword(password: string, hash: string): Promise<boolean> {
  const bcrypt = await import('bcryptjs')
  return bcrypt.compare(password, hash)
}

export function md5File(buffer: Buffer): string {
  return crypto.createHash('md5').update(buffer).digest('hex')
}

export function sha256(input: string): string {
  return crypto.createHash('sha256').update(input).digest('hex')
}
