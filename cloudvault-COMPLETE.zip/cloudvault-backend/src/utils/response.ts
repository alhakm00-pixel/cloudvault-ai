import { Response } from 'express'
import { ApiResponse } from '../types'

export function sendSuccess<T>(
  res: Response,
  data?: T,
  message = 'نجح الطلب',
  statusCode = 200,
  meta?: ApiResponse['meta'],
) {
  return res.status(statusCode).json({ success: true, message, data, meta } satisfies ApiResponse<T>)
}

export function sendError(
  res: Response,
  message = 'حدث خطأ غير متوقع',
  statusCode = 500,
  error?: string,
) {
  return res.status(statusCode).json({ success: false, message, error } satisfies ApiResponse)
}

export function sendPaginated<T>(
  res: Response,
  data: T[],
  total: number,
  page: number,
  limit: number,
  message = 'نجح الطلب',
) {
  return res.status(200).json({
    success: true, message, data,
    meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
  } satisfies ApiResponse<T[]>)
}
