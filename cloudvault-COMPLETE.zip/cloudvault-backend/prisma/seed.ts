import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱  Seeding database...')

  // ─── Admin user ──────────────────────────────────────────────────────────
  const adminHash = await bcrypt.hash('Admin@123456', 12)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@cloudvault.ai' },
    update: {},
    create: {
      name: 'مدير النظام',
      email: 'admin@cloudvault.ai',
      password: adminHash,
      emailVerified: true,
      role: 'ADMIN',
      plan: 'ENTERPRISE',
      storageTotal: BigInt('10995116277760'), // 10TB
    },
  })
  console.log(`✅  Admin: ${admin.email}`)

  // ─── Demo user ───────────────────────────────────────────────────────────
  const demoHash = await bcrypt.hash('Demo@123456', 12)
  const demo = await prisma.user.upsert({
    where: { email: 'demo@cloudvault.ai' },
    update: {},
    create: {
      name: 'أحمد محمد',
      email: 'demo@cloudvault.ai',
      password: demoHash,
      emailVerified: true,
      plan: 'PRO',
      storageUsed: BigInt('909077811200'), // 847 GB
      storageTotal: BigInt('2199023255552'), // 2TB
    },
  })
  console.log(`✅  Demo user: ${demo.email}`)

  // ─── Demo folders ─────────────────────────────────────────────────────────
  const folders = await Promise.all([
    prisma.folder.upsert({
      where: { id: 'folder-videos' },
      update: {},
      create: { id: 'folder-videos', name: 'مقاطع الفيديو', userId: demo.id, color: '#8b5cf6', icon: '🎬' },
    }),
    prisma.folder.upsert({
      where: { id: 'folder-docs' },
      update: {},
      create: { id: 'folder-docs', name: 'المستندات', userId: demo.id, color: '#3b82f6', icon: '📄' },
    }),
    prisma.folder.upsert({
      where: { id: 'folder-photos' },
      update: {},
      create: { id: 'folder-photos', name: 'الصور', userId: demo.id, color: '#ec4899', icon: '🖼️' },
    }),
  ])
  console.log(`✅  Folders: ${folders.length}`)

  // ─── Welcome notification ─────────────────────────────────────────────────
  const existingNotif = await prisma.notification.findFirst({
    where: { userId: demo.id, type: 'welcome' },
  })
  if (!existingNotif) {
    await prisma.notification.create({
      data: {
        userId: demo.id,
        title: 'مرحباً بك في CloudVault AI! 🎉',
        message: 'حسابك جاهز مع 2TB مساحة مجانية. جرّب رفع ملفاتك الآن.',
        type: 'welcome',
      },
    })
  }

  console.log('✅  Welcome notification')
  console.log('\n🎉  Seed complete!')
  console.log('─────────────────────────────────────')
  console.log('  Admin:     admin@cloudvault.ai  / Admin@123456')
  console.log('  Demo User: demo@cloudvault.ai   / Demo@123456')
  console.log('─────────────────────────────────────')
}

main()
  .catch((e) => { console.error('Seed error:', e); process.exit(1) })
  .finally(() => prisma.$disconnect())
